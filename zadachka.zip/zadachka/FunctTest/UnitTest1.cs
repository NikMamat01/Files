using Microsoft.VisualStudio.TestTools.UnitTesting;
using zadachka;
using System;

namespace FunctTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1() // ������ �������
        {
            var Funkt1 = new Function();
            double a = 2;
            double b = 3;
            double c = 5;
            double x = 1;
            double f = 4;
            double result = Funkt1.Funkzia_1(a, b, c, x);
            try
            {
                Assert.AreEqual(f, result);
            }
            catch
            {
                Assert.Fail("������!");
            }
        }
        [TestMethod]
        public void TestMethod2() // ������ �������
        {
            var Funkt1 = new Function();
            double a = 2;
            double b = 0;
            double c = 5;
            double x = 4;
            double f = -2;
            double result = Funkt1.Funkzia_2(a, b, c, x);
            try
            {
                Assert.AreEqual(f, result);
            }
            catch
            {
                Assert.Fail("������!");
            }
        }
        [TestMethod]
        public void TestMethod3() // ������ ������� (� = 3 � b = 0)
        {
            var Funkt1 = new Function();
            double a = 2;
            double b = 0; // 0
            double c = 1;
            double x = 3; // = 3
            double f = 3;
            double result = Funkt1.Funkzia_3(a, b, c, x);
            try
            {
                Assert.AreEqual(f, result);
            }
            catch
            {
                Assert.Fail("������!");
            }
        }

        [TestMethod]
        public void TestMethod4() // ������ ������� (� = 3 � b != 0)
        {
            var Funkt1 = new Function();
            double a = 45;
            double b = 8; // !=0 
            double c = 3;
            double x = 3; // = 3
            double f = 1;
            double result = Funkt1.Funkzia_3(a, b, c, x);
            try
            {
                Assert.AreEqual(f, result);
            }
            catch
            {
                Assert.Fail("������!");
            }
        }
       
        [TestMethod]
        public void TestMethod5() // ������ ������� (� > 3 � b != 0)
        {
            var Funkt1 = new Function();
            double a = 45;
            double b = 6;
            double c = 2;
            double x = 4;
            double f = 2;
            double result = Funkt1.Funkzia_3(a, b, c, x);
            try
            {
                Assert.AreEqual(f, result);
            }
            catch
            {
                Assert.Fail("������!");
            }
        }
        [TestMethod]
        public void TestMethod55() // ������ ������� (� < 3 � b = 0)
        {
            var Funkt1 = new Function();
            double a = 45;
            double b = 0;
            double c = 2;
            double x = 2;
            double f = 1;
            double result = Funkt1.Funkzia_3(a, b, c, x);
            try
            {
                Assert.AreEqual(f, result);
            }
            catch
            {
                Assert.Fail("������!");
            }
        }

        [TestMethod]
        public void TestMethod111() // ������ ������� (����� � �������)
        {
            var Funkt1 = new Function();
            double a = 0.5;
            double b = 0.5;
            double c = 0.5;
            double x = 0.5;
            double f = 0.375;
            double result = Funkt1.Funkzia_1(a, b, c, x);
            try
            {
                Assert.AreEqual(f, result);
            }
            catch
            {
                Assert.Fail("������!");
            }
        }
        [TestMethod]
        public void TestMethod22() // ������ ������� (����� � �������)
        {
            var Funkt1 = new Function();
            double a = 0.5;
            double b = 0;
            double c = 0.5;
            double x = 3.5;
            double f = 1;
            double result = Funkt1.Funkzia_2(a, b, c, x);
            try
            {
                Assert.AreEqual(f, result);
            }
            catch
            {
                Assert.Fail("������!");
            }
        }
        [TestMethod]
        public void TestMethod33() // ������ ������� (� = 3 � b = 0) ����� � �������
        {
            var Funkt1 = new Function();
            double a = 0.5;
            double b = 0; 
            double c = 0.5;
            double x = 3; 
            double f = 6;
            double result = Funkt1.Funkzia_3(a, b, c, x);
            try
            {
                Assert.AreEqual(f, result);
            }
            catch
            {
                Assert.Fail("������!");
            }
        }
        [TestMethod]
        public void TestMethod333() // ������ ������� (� = 3 � b != 0) ����� � �������
        {
            var Funkt1 = new Function();
            double a = 0.5;
            double b = 1.5; 
            double c = 0.5;
            double x = 3; 
            double f = 6;
            double result = Funkt1.Funkzia_3(a, b, c, x);
            try
            {
                Assert.AreEqual(f, result);
            }
            catch
            {
                Assert.Fail("������!");
            }
        }
        [TestMethod]
        public void TestMethod3333() // ������ ������� (� < 3 � b = 0) ����� � �������
        {
            var Funkt1 = new Function();
            double a = 0.5;
            double b = 0; 
            double c = 0.5;
            double x = 2.5; 
            double f = 5;
            double result = Funkt1.Funkzia_3(a, b, c, x);
            try
            {
                Assert.AreEqual(f, result);
            }
            catch
            {
                Assert.Fail("������!");
            }
        }
        [TestMethod]
        public void TestMethod33333() // ������ ������� (� < 3 � b = 0) ����� � �������
        {
            var Funkt1 = new Function();
            double a = 0.5;
            double b = 0.5;
            double c = 0.5;
            double x = 3.5;
            double f = 7;
            double result = Funkt1.Funkzia_3(a, b, c, x);
            try
            {
                Assert.AreEqual(f, result);
            }
            catch
            {
                Assert.Fail("������!");
            }
        }
    }
}

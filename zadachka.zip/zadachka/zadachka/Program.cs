﻿using System;

namespace zadachka
{
    public class Function
    {
        public double Funkzia_1(double a, double b, double c, double x)
        {
            if (x < 3 && b != 0)
            {
                return a * x * x - b * x + c;
            }
            else throw new Exception("Ошибка!");
        }
        public double Funkzia_2(double a, double b, double c, double x)
        {
            if (x > 3 && b == 0)
            {
                return (x - a) / (x - c);
            }
            else throw new Exception("Ошибка!");
        }
        public double Funkzia_3(double a, double b, double c, double x)
        {
            if (x == 3) // х = 3 
            {
                return x / c;
            }
            else if ((x < 3 && b == 0)) // противоречащее значение funkzia_1
            {
                return x / c;
            }
            else if ((x > 3 && b != 0)) // противоречащее значение funkzia_2
            {
                return x / c;
            }
            else throw new Exception("Ошибка!");
        }
        static void Main(string[] args)
        {

        }
    }
}



﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace Муржолье
{
    public partial class Заказ : Form
    {
        
        public Заказ()
        {
            InitializeComponent();
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ControlBox = false;
            this.MinimizeBox = false;
            this.MaximizeBox = false;
            Random rand = new Random();
            int value = rand.Next(500, 1000);
            баланс.Text = value.ToString();
        }
        private void закаааз_Click(object sender, EventArgs e)
        {
            Excel.Application application = null;
            Excel.Workbooks workbooks = null;
            Excel.Workbook workbook = null;
            Excel.Sheets worksheets = null;
            Excel.Worksheet worksheet = null;
            Excel.Range cell = null;
            application = new Excel.Application
            {
                Visible = false
            };
            workbooks = application.Workbooks;
            workbook = workbooks.Add();
            worksheets = workbook.Worksheets;
            worksheet = worksheets.Item[1];
            cell = worksheet.Cells[1, 1];
            cell.Font.Size = 16;
            cell.Font.Italic = true;
            cell.Font.Bold = true;
            cell.Font.Color = Color.Red;
            cell.Value = "Кафе -Муржолье- ";
            cell = worksheet.Cells[1, 6];
            cell.Font.Size = 16;
            cell.Font.Italic = true;
            cell.Font.Bold = true;
            cell.Font.Color = Color.Blue;
            DateTime date = DateTime.Now;
            string date2 = date.ToString();
            cell.Value = date2;
            cell = worksheet.Cells[2, 1];
            cell.Font.Bold = true;
            cell.Font.Color = Color.Orange;
            cell.Value = "Название";
            cell = worksheet.Cells[2, 2];
            cell.Font.Bold = true;
            cell.Font.Color = Color.Orange;
            cell.Value = "Калорийность (ккал.)";
            cell = worksheet.Cells[2, 3];
            cell.Font.Bold = true;
            cell.Font.Color = Color.Orange;
            cell.Value = "Вес (гр.)";
            cell = worksheet.Cells[2, 4];
            cell.Font.Bold = true;
            cell.Font.Color = Color.Orange;
            cell.Value = "Цена (руб.)";
            Microsoft.Office.Interop.Word.Application winword =
            new Microsoft.Office.Interop.Word.Application();
            winword.Visible = false;
            object missing = System.Reflection.Missing.Value;
            Microsoft.Office.Interop.Word.Document document =
            winword.Documents.Add(ref missing, ref missing, ref missing, ref missing);
            Microsoft.Office.Interop.Word.Paragraph para2 = document.Content.Paragraphs.Add(ref missing);
            para2.Range.Text = "Кафе -Муржолье- Дата: " + DateTime.Now;
            para2.Range.InsertParagraphAfter();
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Салаты"];
                double a = xlSht.Range["D3"].Value;
                double a1 = xlSht.Range["D4"].Value;
                double a2 = xlSht.Range["D5"].Value;
                xlSht = xlWB.Worksheets["Горячее"];
                double b = xlSht.Range["D3"].Value;
                double b1 = xlSht.Range["D4"].Value;
                double b2 = xlSht.Range["D5"].Value;
                xlSht = xlWB.Worksheets["Супы"];
                double c = xlSht.Range["D3"].Value;
                double c1 = xlSht.Range["D4"].Value;
                double c2 = xlSht.Range["D5"].Value;
                xlSht = xlWB.Worksheets["Десерты"];
                double d = xlSht.Range["D3"].Value;
                double d1 = xlSht.Range["D4"].Value;
                double d2 = xlSht.Range["D5"].Value;
                xlSht = xlWB.Worksheets["Напитки"];
                double e1 = xlSht.Range["D3"].Value;
                double e2 = xlSht.Range["D4"].Value;
                double e3 = xlSht.Range["D5"].Value;
                double e4 = xlSht.Range["D6"].Value;
                double e5 = xlSht.Range["D7"].Value;
                double e6 = xlSht.Range["D8"].Value;
                double e7 = xlSht.Range["D9"].Value;
                double k = 0;
                if (Цезарь.Enabled == false)
                {
                    k += a;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[3, 1];
                    cell.Value = "Цезарь";
                    cell = worksheet.Cells[3, 2];
                    cell.Value = "430";
                    cell = worksheet.Cells[3, 3];
                    cell.Value = "200";
                    cell = worksheet.Cells[3, 4];
                    cell.Value = "130";
                    Microsoft.Office.Interop.Word.Paragraph para1 = document.Content.Paragraphs.Add(ref missing);
                    para1.Range.Text = "Цезарь - 430 ккал. - 200 гр. - 130 рублей";
                    para1.Range.InsertParagraphAfter();
                }
                if (Оливье.Enabled == false)
                {
                    k += a1;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[4, 1];
                    cell.Value = "Оливье";
                    cell = worksheet.Cells[4, 2];
                    cell.Value = "325";
                    cell = worksheet.Cells[4, 3];
                    cell.Value = "200";
                    cell = worksheet.Cells[4, 4];
                    cell.Value = "130";
                    Microsoft.Office.Interop.Word.Paragraph para3 = document.Content.Paragraphs.Add(ref missing);
                    para3.Range.Text = "Оливье - 325 ккал. - 200 гр. - 130 рублей";
                    para3.Range.InsertParagraphAfter();
                }
                if (Селёдка.Enabled == false)
                {
                    k += a2;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[5, 1];
                    cell.Value = "Селёдка";
                    cell = worksheet.Cells[5, 2];
                    cell.Value = "396";
                    cell = worksheet.Cells[5, 3];
                    cell.Value = "200";
                    cell = worksheet.Cells[5, 4];
                    cell.Value = "130";
                    Microsoft.Office.Interop.Word.Paragraph para4 = document.Content.Paragraphs.Add(ref missing);
                    para4.Range.Text = "Селёдка - 396 ккал. - 200 гр. - 130 рублей";
                    para4.Range.InsertParagraphAfter();
                }
                if (Макароны.Enabled == false)
                {
                    k += b;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[6, 1];
                    cell.Value = "Макароны";
                    cell = worksheet.Cells[6, 2];
                    cell.Value = "527";
                    cell = worksheet.Cells[6, 3];
                    cell.Value = "200";
                    cell = worksheet.Cells[6, 4];
                    cell.Value = "150";
                    Microsoft.Office.Interop.Word.Paragraph para5 = document.Content.Paragraphs.Add(ref missing);
                    para5.Range.Text = "Макароны - 527 ккал. - 200 гр. - 150 рублей";
                    para5.Range.InsertParagraphAfter();
                }
                if (Картошка.Enabled == false)
                {
                    k += b1;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[7, 1];
                    cell.Value = "Картошка";
                    cell = worksheet.Cells[7, 2];
                    cell.Value = "302";
                    cell = worksheet.Cells[7, 3];
                    cell.Value = "200";
                    cell = worksheet.Cells[7, 4];
                    cell.Value = "150";
                    Microsoft.Office.Interop.Word.Paragraph para6 = document.Content.Paragraphs.Add(ref missing);
                    para6.Range.Text = "Картошка - 302 ккал. - 200 гр. - 150 рублей";
                    para6.Range.InsertParagraphAfter();
                }
                if (Плов.Enabled == false)
                {
                    k += b2;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[8, 1];
                    cell.Value = "Плов";
                    cell = worksheet.Cells[8, 2];
                    cell.Value = "348";
                    cell = worksheet.Cells[8, 3];
                    cell.Value = "200";
                    cell = worksheet.Cells[8, 4];
                    cell.Value = "150";
                    Microsoft.Office.Interop.Word.Paragraph para7 = document.Content.Paragraphs.Add(ref missing);
                    para7.Range.Text = "Плов - 348 ккал. - 200 гр. - 150 рублей";
                    para7.Range.InsertParagraphAfter();
                }
                if (Борщ.Enabled == false)
                {
                    k += c;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[9, 1];
                    cell.Value = "Борщ";
                    cell = worksheet.Cells[9, 2];
                    cell.Value = "115";
                    cell = worksheet.Cells[9, 3];
                    cell.Value = "200";
                    cell = worksheet.Cells[9, 4];
                    cell.Value = "120";
                    Microsoft.Office.Interop.Word.Paragraph para8 = document.Content.Paragraphs.Add(ref missing);
                    para8.Range.Text = "Борщ - 115 ккал. - 200 гр. - 120 рублей";
                    para8.Range.InsertParagraphAfter();
                }
                if (Щи.Enabled == false)
                {
                    k += c1;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[10, 1];
                    cell.Value = "Щи";
                    cell = worksheet.Cells[10, 2];
                    cell.Value = "75";
                    cell = worksheet.Cells[10, 3];
                    cell.Value = "200";
                    cell = worksheet.Cells[10, 4];
                    cell.Value = "120";
                    Microsoft.Office.Interop.Word.Paragraph para9 = document.Content.Paragraphs.Add(ref missing);
                    para9.Range.Text = "Щи - 75 ккал. - 200 гр. - 120 рублей";
                    para9.Range.InsertParagraphAfter();
                }
                if (Уха.Enabled == false)
                {
                    k += c2;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[11, 1];
                    cell.Value = "Уха";
                    cell = worksheet.Cells[11, 2];
                    cell.Value = "98";
                    cell = worksheet.Cells[11, 3];
                    cell.Value = "200";
                    cell = worksheet.Cells[11, 4];
                    cell.Value = "120";
                    Microsoft.Office.Interop.Word.Paragraph para10 = document.Content.Paragraphs.Add(ref missing);
                    para10.Range.Text = "Уха - 98 ккал. - 200 гр. - 120 рублей";
                    para10.Range.InsertParagraphAfter();
                }
                if (Тирамису.Enabled == false)
                {
                    k += d;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[12, 1];
                    cell.Value = "Тирамису";
                    cell = worksheet.Cells[12, 2];
                    cell.Value = "144";
                    cell = worksheet.Cells[12, 3];
                    cell.Value = "50";
                    cell = worksheet.Cells[12, 4];
                    cell.Value = "50";
                    Microsoft.Office.Interop.Word.Paragraph para11 = document.Content.Paragraphs.Add(ref missing);
                    para11.Range.Text = "Тирамису - 144 ккал. - 50 гр. - 50 рублей";
                    para11.Range.InsertParagraphAfter();
                }
                if (Чизкейк.Enabled == false)
                {
                    k += d1;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[13, 1];
                    cell.Value = "Чизкейк";
                    cell = worksheet.Cells[13, 2];
                    cell.Value = "123";
                    cell = worksheet.Cells[13, 3];
                    cell.Value = "50";
                    cell = worksheet.Cells[13, 4];
                    cell.Value = "50";
                    Microsoft.Office.Interop.Word.Paragraph para12 = document.Content.Paragraphs.Add(ref missing);
                    para12.Range.Text = "Чизкейк - 123 ккал. - 50 гр. - 50 рублей";
                    para12.Range.InsertParagraphAfter();
                }
                if (Эклер.Enabled == false)
                {
                    k += d2;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[13, 1];
                    cell.Value = "Эклер";
                    cell = worksheet.Cells[13, 2];
                    cell.Value = "218";
                    cell = worksheet.Cells[13, 3];
                    cell.Value = "50";
                    cell = worksheet.Cells[13, 4];
                    cell.Value = "50";
                    Microsoft.Office.Interop.Word.Paragraph para13 = document.Content.Paragraphs.Add(ref missing);
                    para13.Range.Text = "Эклер - 218 ккал. - 50 гр. - 50 рублей";
                    para13.Range.InsertParagraphAfter();
                }
                if (Чай.Enabled == false)
                {
                    k += e1;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[14, 1];
                    cell.Value = "Чай черный";
                    cell = worksheet.Cells[14, 2];
                    cell.Value = "50";
                    cell = worksheet.Cells[14, 3];
                    cell.Value = "100";
                    cell = worksheet.Cells[14, 4];
                    cell.Value = "20";
                    Microsoft.Office.Interop.Word.Paragraph para14 = document.Content.Paragraphs.Add(ref missing);
                    para14.Range.Text = "Чай чёрный - 50 ккал. - 100 гр. - 20 рублей";
                    para14.Range.InsertParagraphAfter();
                }
                if (зеленый.Enabled == false)
                {
                    k += e2;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[15, 1];
                    cell.Value = "Чай зелёный";
                    cell = worksheet.Cells[15, 2];
                    cell.Value = "27";
                    cell = worksheet.Cells[15, 3];
                    cell.Value = "100";
                    cell = worksheet.Cells[15, 4];
                    cell.Value = "20";
                    Microsoft.Office.Interop.Word.Paragraph para15 = document.Content.Paragraphs.Add(ref missing);
                    para15.Range.Text = "Чай зелёный - 27 ккал. - 100 гр. - 20 рублей";
                    para15.Range.InsertParagraphAfter();
                }
                if (Вода.Enabled == false)
                {
                    k += e3;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[16, 1];
                    cell.Value = "Вода без газа";
                    cell = worksheet.Cells[16, 2];
                    cell.Value = "0";
                    cell = worksheet.Cells[16, 3];
                    cell.Value = "500";
                    cell = worksheet.Cells[16, 4];
                    cell.Value = "35";
                    Microsoft.Office.Interop.Word.Paragraph para16 = document.Content.Paragraphs.Add(ref missing);
                    para16.Range.Text = "Вода без газа - 0 ккал. - 500 гр. - 35 рублей";
                    para16.Range.InsertParagraphAfter();
                }
                if (водасгазом.Enabled == false)
                {
                    k += e4;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[17, 1];
                    cell.Value = "Вода с газом";
                    cell = worksheet.Cells[17, 2];
                    cell.Value = "215";
                    cell = worksheet.Cells[17, 3];
                    cell.Value = "500";
                    cell = worksheet.Cells[17, 4];
                    cell.Value = "35";
                    Microsoft.Office.Interop.Word.Paragraph para17 = document.Content.Paragraphs.Add(ref missing);
                    para17.Range.Text = "Вода с газом - 215 ккал. - 500 гр. - 35 рублей";
                    para17.Range.InsertParagraphAfter();
                }
                if (Газировка.Enabled == false)
                {
                    k += e5;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[18, 1];
                    cell.Value = "Pepsi";
                    cell = worksheet.Cells[18, 2];
                    cell.Value = "130";
                    cell = worksheet.Cells[18, 3];
                    cell.Value = "500";
                    cell = worksheet.Cells[18, 4];
                    cell.Value = "40";
                    Microsoft.Office.Interop.Word.Paragraph para18 = document.Content.Paragraphs.Add(ref missing);
                    para18.Range.Text = "Pepsi - 215 ккал. - 500 гр. - 40 рублей";
                    para18.Range.InsertParagraphAfter();
                }
                if (миринда.Enabled == false)
                {
                    k += e6;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[19, 1];
                    cell.Value = "Mirinda";
                    cell = worksheet.Cells[19, 2];
                    cell.Value = "210";
                    cell = worksheet.Cells[19, 3];
                    cell.Value = "500";
                    cell = worksheet.Cells[19, 4];
                    cell.Value = "40";
                    Microsoft.Office.Interop.Word.Paragraph para19 = document.Content.Paragraphs.Add(ref missing);
                    para19.Range.Text = "Mirinda - 210 ккал. - 500 гр. - 40 рублей";
                    para19.Range.InsertParagraphAfter();
                }
                if (севенап.Enabled == false)
                {
                    k += e7;
                    worksheets = workbook.Worksheets;
                    worksheet = worksheets.Item[1];
                    cell = worksheet.Cells[19, 1];
                    cell.Value = "7UP";
                    cell = worksheet.Cells[19, 2];
                    cell.Value = "190";
                    cell = worksheet.Cells[19, 3];
                    cell.Value = "500";
                    cell = worksheet.Cells[19, 4];
                    cell.Value = "40";
                    Microsoft.Office.Interop.Word.Paragraph para20 = document.Content.Paragraphs.Add(ref missing);
                    para20.Range.Text = "7UP - 190 ккал. - 500 гр. - 40 рублей";
                    para20.Range.InsertParagraphAfter();
                }
                double nal = Convert.ToDouble(баланс.Text);
                double sdacha1 = nal - k;
                cell = worksheet.Cells[20, 1];
                cell.Value = "Итого:";
                cell = worksheet.Cells[20, 2];
                cell.Value = k.ToString() + " рублей";
                Microsoft.Office.Interop.Word.Paragraph para21 = document.Content.Paragraphs.Add(ref missing);
                para21.Range.Text = "Итого: " + k + " рублей";
                para21.Range.InsertParagraphAfter();

                cell = worksheet.Cells[21, 1];
                cell.Value = "Наличные:";
                cell = worksheet.Cells[21, 2];
                cell.Value = nal.ToString() + " рублей";
                Microsoft.Office.Interop.Word.Paragraph para22 = document.Content.Paragraphs.Add(ref missing);
                para22.Range.Text = "Наличные: " + nal + " рублей";
                para22.Range.InsertParagraphAfter();
                итог.Text = k.ToString();
                sdacha.Text = sdacha1.ToString();
                картина.Visible = true;
                Чек.Items.Add("Итого:");
                Чек.Items.Add(итог.Text + " рублей");
                Чек.Items.Add("-----------------------");
                if (sdacha1 >= 0)
                {
                    вердикт.Text = "Оплата наличными или картой?";
                    кнопка.Enabled = true;
                    кнопка2.Enabled = true;
                    cell = worksheet.Cells[22, 1];
                    cell.Value = "Сдача:";
                    cell = worksheet.Cells[22, 2];
                    cell.Value = sdacha1.ToString() + " рублей";
                    Microsoft.Office.Interop.Word.Paragraph para23 = document.Content.Paragraphs.Add(ref missing);
                    para23.Range.Text = "Сдача: " + sdacha1 + " рублей";
                    para23.Range.InsertParagraphAfter();
                    cell = worksheet.Cells[23, 1];
                    cell.Value = "Оплата осуществлена наличными или картой!";
                    Microsoft.Office.Interop.Word.Paragraph para24 = document.Content.Paragraphs.Add(ref missing);
                    para24.Range.Text = "Оплата осуществлена наличными или картой!";
                    para24.Range.InsertParagraphAfter();
                }
                else
                {
                    вердикт.Text = "Оплата только банковской картой!";
                    кнопка.Enabled = false;
                    кнопка2.Enabled = true;
                    cell = worksheet.Cells[22, 1];
                    cell.Value = "Сдача:";
                    cell = worksheet.Cells[22, 2];
                    cell.Value = sdacha1.ToString() + " рублей";
                    Microsoft.Office.Interop.Word.Paragraph para25 = document.Content.Paragraphs.Add(ref missing);
                    para25.Range.Text = "Сдача: " + sdacha1 + " рублей";
                    para25.Range.InsertParagraphAfter();
                    cell = worksheet.Cells[23, 1];
                    cell.Value = "Оплата осуществлена картой!";
                    Microsoft.Office.Interop.Word.Paragraph para26 = document.Content.Paragraphs.Add(ref missing);
                    para26.Range.Text = "Оплата осуществлена картой!";
                    para26.Range.InsertParagraphAfter();
                }
                DateTime datenow = DateTime.Now;
                string datetimenow = datenow.ToString();
                string pathBook = path + @"\" + datenow.ToShortDateString() + ".xls";
                string wooorkBook = path + @"\" + datenow.ToShortDateString();
                workbook.SaveAs(pathBook, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                             Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing,
                             Type.Missing, Type.Missing);
                workbook.Close(true, null, null);
                document.SaveAs(wooorkBook + ".docx");
                document.SaveAs(wooorkBook + ".pdf");
                winword.Quit(true, null, null);
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void checkguess()
        {

        }

        private void Цезарь_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Салаты"];
                string a = xlSht.Range["A3"].Value;
                double b = xlSht.Range["B3"].Value;
                double c = xlSht.Range["C3"].Value;
                double d = xlSht.Range["D3"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Цезарь.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Оливье_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Салаты"];
                string a = xlSht.Range["A4"].Value;
                double b = xlSht.Range["B4"].Value;
                double c = xlSht.Range["C4"].Value;
                double d = xlSht.Range["D4"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Оливье.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

            private void Селёдка_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Салаты"];
                string a = xlSht.Range["A5"].Value;
                double b = xlSht.Range["B5"].Value;
                double c = xlSht.Range["C5"].Value;
                double d = xlSht.Range["D5"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Селёдка.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

            private void Борщ_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Супы"];
                string a = xlSht.Range["A3"].Value;
                double b = xlSht.Range["B3"].Value;
                double c = xlSht.Range["C3"].Value;
                double d = xlSht.Range["D3"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Борщ.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

            private void Щи_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Супы"];
                string a = xlSht.Range["A4"].Value;
                double b = xlSht.Range["B4"].Value;
                double c = xlSht.Range["C4"].Value;
                double d = xlSht.Range["D4"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Щи.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Уха_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Супы"];
                string a = xlSht.Range["A5"].Value;
                double b = xlSht.Range["B5"].Value;
                double c = xlSht.Range["C5"].Value;
                double d = xlSht.Range["D5"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Уха.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Чай_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Напитки"];
                string a = xlSht.Range["A3"].Value;
                double b = xlSht.Range["B3"].Value;
                double c = xlSht.Range["C3"].Value;
                double d = xlSht.Range["D3"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " мл.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Чай.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

            private void Вода_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Напитки"];
                string a = xlSht.Range["A5"].Value;
                double b = xlSht.Range["B5"].Value;
                double c = xlSht.Range["C5"].Value;
                double d = xlSht.Range["D5"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " мл.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Вода.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Газировка_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Напитки"];
                string a = xlSht.Range["A7"].Value;
                double b = xlSht.Range["B7"].Value;
                double c = xlSht.Range["C7"].Value;
                double d = xlSht.Range["D7"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " мл.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Газировка.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Макароны_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Горячее"];
                string a = xlSht.Range["A3"].Value;
                double b = xlSht.Range["B3"].Value;
                double c = xlSht.Range["C3"].Value;
                double d = xlSht.Range["D3"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Макароны.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Картошка_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Горячее"];
                string a = xlSht.Range["A4"].Value;
                double b = xlSht.Range["B4"].Value;
                double c = xlSht.Range["C4"].Value;
                double d = xlSht.Range["D4"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Картошка.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Плов_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Горячее"];
                string a = xlSht.Range["A5"].Value;
                double b = xlSht.Range["B5"].Value;
                double c = xlSht.Range["C5"].Value;
                double d = xlSht.Range["D5"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Плов.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Тирамису_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Десерты"];
                string a = xlSht.Range["A3"].Value;
                double b = xlSht.Range["B3"].Value;
                double c = xlSht.Range["C3"].Value;
                double d = xlSht.Range["D3"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Тирамису.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Чизкейк_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Десерты"];
                string a = xlSht.Range["A4"].Value;
                double b = xlSht.Range["B4"].Value;
                double c = xlSht.Range["C4"].Value;
                double d = xlSht.Range["D4"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Чизкейк.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Эклер_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Десерты"];
                string a = xlSht.Range["A5"].Value;
                double b = xlSht.Range["B5"].Value;
                double c = xlSht.Range["C5"].Value;
                double d = xlSht.Range["D5"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Эклер.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Чек_SelectedIndexChanged(object sender, EventArgs e)
        {
            

    }

        private void зеленый_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Напитки"];
                string a = xlSht.Range["A4"].Value;
                double b = xlSht.Range["B4"].Value;
                double c = xlSht.Range["C4"].Value;
                double d = xlSht.Range["D4"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " мл.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                зеленый.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void водасгазом_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath; 
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx"; 
            if ((System.IO.File.Exists(fileName)))   
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Напитки"];
                string a = xlSht.Range["A6"].Value;
                double b = xlSht.Range["B6"].Value;
                double c = xlSht.Range["C6"].Value;
                double d = xlSht.Range["D6"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " мл.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                водасгазом.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void миринда_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Напитки"];
                string a = xlSht.Range["A8"].Value;
                double b = xlSht.Range["B8"].Value;
                double c = xlSht.Range["C8"].Value;
                double d = xlSht.Range["D8"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " мл.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                миринда.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void севенап_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath; 
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx"; 
            if ((System.IO.File.Exists(fileName)))   
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Напитки"];
                string a = xlSht.Range["A9"].Value;
                double b = xlSht.Range["B9"].Value;
                double c = xlSht.Range["C9"].Value;
                double d = xlSht.Range["D9"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " мл.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                севенап.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void кнопка_Click(object sender, EventArgs e)
        {
            int bal = Int32.Parse(баланс.Text);
            int itog = Int32.Parse(итог.Text);
            int sdacha1 = Int32.Parse(sdacha.Text);
            Чек.Items.Add("Оплата наличными.");
            Чек.Items.Add("Наличные: " + bal + " рублей");
            Чек.Items.Add("Сдача: " + sdacha1 + " рублей");
            Чек.Items.Add("-----------------------");
            MessageBox.Show("Ваш заказ составил на сумму: " + (itog).ToString() + " рублей. Вы решили оплатить заказ наличными на сумму: " + (bal).ToString() + " рублей. Ваша сдача: " + (sdacha1).ToString() + " рублей. Ваш заказ принят! Приятного аппетита! :) ");
            const string sPath = "nal.txt";
            using (System.IO.StreamWriter sw = new System.IO.StreamWriter(sPath))
            {
                for (int i = 0; i < Чек.Items.Count; i++)
                    sw.WriteLine(Чек.Items[i].ToString());
            }
            this.Hide();
            Муржолье f22 = new Муржолье();
            f22.Show();
        }

        private void Заказ_Load(object sender, EventArgs e)
        {

        }

        private void кнопка2_Click(object sender, EventArgs e)
        {
            double itog = Convert.ToDouble(итог.Text);
            double keshbek = itog * 0.1;
            Чек.Items.Add("Оплата банковской картой.");
            Чек.Items.Add("Кэшбэк: " + keshbek + " рублей");
            Чек.Items.Add("-----------------------");
            MessageBox.Show("Ваш заказ составил на сумму: " + (itog).ToString() + " рублей. Вы решили оплатить заказ банковской картой. Мы дарим вам кэшбэк 10% от заказа, то есть: " + (keshbek).ToString() + " рублей. Ваш заказ принят! Приятного аппетита! :) ");
            const string sPath = "besnal.txt";
            using (System.IO.StreamWriter sw = new System.IO.StreamWriter(sPath))
            {
                for (int i = 0; i < Чек.Items.Count; i++)
                    sw.WriteLine(Чек.Items[i].ToString());
            }
            this.Hide();
            Муржолье f22 = new Муржолье();
            f22.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void итог_Click(object sender, EventArgs e)
        {

        }

        private void sdacha_Click(object sender, EventArgs e)
        {

        }

        private void баланс_Click(object sender, EventArgs e)
        {

        }
    }
}

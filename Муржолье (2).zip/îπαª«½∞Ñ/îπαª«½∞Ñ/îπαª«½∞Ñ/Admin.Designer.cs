﻿
namespace Муржолье
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            this.открой = new System.Windows.Forms.Button();
            this.выйти = new System.Windows.Forms.Button();
            this.клик = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // открой
            // 
            this.открой.Location = new System.Drawing.Point(12, 12);
            this.открой.Name = "открой";
            this.открой.Size = new System.Drawing.Size(130, 34);
            this.открой.TabIndex = 0;
            this.открой.Text = "Открыть меню кафе";
            this.открой.UseVisualStyleBackColor = true;
            this.открой.Click += new System.EventHandler(this.открой_Click);
            // 
            // выйти
            // 
            this.выйти.Location = new System.Drawing.Point(184, 240);
            this.выйти.Name = "выйти";
            this.выйти.Size = new System.Drawing.Size(94, 34);
            this.выйти.TabIndex = 1;
            this.выйти.Text = "Выйти";
            this.выйти.UseVisualStyleBackColor = true;
            this.выйти.Click += new System.EventHandler(this.выйти_Click);
            // 
            // клик
            // 
            this.клик.Location = new System.Drawing.Point(12, 240);
            this.клик.Name = "клик";
            this.клик.Size = new System.Drawing.Size(166, 34);
            this.клик.TabIndex = 2;
            this.клик.Text = "Вернуть кликабельность";
            this.клик.UseVisualStyleBackColor = true;
            this.клик.Click += new System.EventHandler(this.клик_Click);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(290, 286);
            this.Controls.Add(this.клик);
            this.Controls.Add(this.выйти);
            this.Controls.Add(this.открой);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Admin";
            this.Text = "Admin";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button открой;
        private System.Windows.Forms.Button выйти;
        private System.Windows.Forms.Button клик;
    }
}
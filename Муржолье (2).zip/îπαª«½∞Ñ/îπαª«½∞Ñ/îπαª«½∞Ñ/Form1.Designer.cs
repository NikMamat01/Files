﻿
namespace Муржолье
{
    partial class Муржолье
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Муржолье));
            this.Текст = new System.Windows.Forms.Label();
            this.Заказ = new System.Windows.Forms.Button();
            this.Прайслист = new System.Windows.Forms.Button();
            this.Закрытие = new System.Windows.Forms.Button();
            this.Персонал = new System.Windows.Forms.Button();
            this.Подсказка = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // Текст
            // 
            this.Текст.AutoSize = true;
            this.Текст.Font = new System.Drawing.Font("Segoe Script", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Текст.ForeColor = System.Drawing.Color.White;
            this.Текст.Location = new System.Drawing.Point(45, 42);
            this.Текст.Name = "Текст";
            this.Текст.Size = new System.Drawing.Size(187, 48);
            this.Текст.TabIndex = 0;
            this.Текст.Text = "Муржолье";
            // 
            // Заказ
            // 
            this.Заказ.Location = new System.Drawing.Point(47, 109);
            this.Заказ.Name = "Заказ";
            this.Заказ.Size = new System.Drawing.Size(184, 35);
            this.Заказ.TabIndex = 1;
            this.Заказ.Text = "Сделать заказ";
            this.Заказ.UseVisualStyleBackColor = true;
            this.Заказ.Click += new System.EventHandler(this.Заказ_Click);
            this.Заказ.MouseHover += new System.EventHandler(this.Заказ_MouseHover);
            // 
            // Прайслист
            // 
            this.Прайслист.Location = new System.Drawing.Point(47, 150);
            this.Прайслист.Name = "Прайслист";
            this.Прайслист.Size = new System.Drawing.Size(184, 35);
            this.Прайслист.TabIndex = 2;
            this.Прайслист.Text = "Прайс-лист";
            this.Прайслист.UseVisualStyleBackColor = true;
            this.Прайслист.Click += new System.EventHandler(this.Прайслист_Click);
            this.Прайслист.MouseHover += new System.EventHandler(this.Прайслист_MouseHover);
            // 
            // Закрытие
            // 
            this.Закрытие.Location = new System.Drawing.Point(48, 232);
            this.Закрытие.Name = "Закрытие";
            this.Закрытие.Size = new System.Drawing.Size(184, 35);
            this.Закрытие.TabIndex = 3;
            this.Закрытие.Text = "Закрыть программу";
            this.Закрытие.UseVisualStyleBackColor = true;
            this.Закрытие.Click += new System.EventHandler(this.Закрытие_Click);
            this.Закрытие.MouseHover += new System.EventHandler(this.Закрытие_MouseHover);
            // 
            // Персонал
            // 
            this.Персонал.Location = new System.Drawing.Point(48, 191);
            this.Персонал.Name = "Персонал";
            this.Персонал.Size = new System.Drawing.Size(184, 35);
            this.Персонал.TabIndex = 4;
            this.Персонал.Text = "Вход для персонала";
            this.Персонал.UseVisualStyleBackColor = true;
            this.Персонал.Click += new System.EventHandler(this.кафе_Click);
            this.Персонал.MouseHover += new System.EventHandler(this.кафе_MouseHover);
            // 
            // Муржолье
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(282, 435);
            this.Controls.Add(this.Персонал);
            this.Controls.Add(this.Закрытие);
            this.Controls.Add(this.Прайслист);
            this.Controls.Add(this.Заказ);
            this.Controls.Add(this.Текст);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Муржолье";
            this.Text = "Кафе \"Муржолье\"";
            this.Load += new System.EventHandler(this.Муржолье_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Текст;
        private System.Windows.Forms.Button Заказ;
        private System.Windows.Forms.Button Прайслист;
        private System.Windows.Forms.Button Закрытие;
        private System.Windows.Forms.Button Персонал;
        private System.Windows.Forms.ToolTip Подсказка;
    }
}


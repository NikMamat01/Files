﻿
namespace Муржолье
{
    partial class Десерты
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Десерты));
            this.Тирамису = new System.Windows.Forms.PictureBox();
            this.Чизкейк = new System.Windows.Forms.PictureBox();
            this.тир = new System.Windows.Forms.Label();
            this.чиз = new System.Windows.Forms.Label();
            this.экл = new System.Windows.Forms.Label();
            this.Десерт_Помощь = new System.Windows.Forms.ToolTip(this.components);
            this.Вернуться2 = new System.Windows.Forms.Button();
            this.Эклер = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Тирамису)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Чизкейк)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Эклер)).BeginInit();
            this.SuspendLayout();
            // 
            // Тирамису
            // 
            this.Тирамису.Image = ((System.Drawing.Image)(resources.GetObject("Тирамису.Image")));
            this.Тирамису.Location = new System.Drawing.Point(21, 31);
            this.Тирамису.Name = "Тирамису";
            this.Тирамису.Size = new System.Drawing.Size(99, 101);
            this.Тирамису.TabIndex = 0;
            this.Тирамису.TabStop = false;
            this.Тирамису.MouseHover += new System.EventHandler(this.Тирамису_MouseHover);
            // 
            // Чизкейк
            // 
            this.Чизкейк.Image = ((System.Drawing.Image)(resources.GetObject("Чизкейк.Image")));
            this.Чизкейк.Location = new System.Drawing.Point(21, 147);
            this.Чизкейк.Name = "Чизкейк";
            this.Чизкейк.Size = new System.Drawing.Size(99, 101);
            this.Чизкейк.TabIndex = 1;
            this.Чизкейк.TabStop = false;
            this.Чизкейк.MouseHover += new System.EventHandler(this.Чизкейк_MouseHover);
            // 
            // тир
            // 
            this.тир.AutoSize = true;
            this.тир.BackColor = System.Drawing.Color.Transparent;
            this.тир.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.тир.ForeColor = System.Drawing.Color.Cyan;
            this.тир.Location = new System.Drawing.Point(133, 60);
            this.тир.Name = "тир";
            this.тир.Size = new System.Drawing.Size(137, 29);
            this.тир.TabIndex = 3;
            this.тир.Text = "50 рублей";
            this.тир.Click += new System.EventHandler(this.label1_Click);
            // 
            // чиз
            // 
            this.чиз.AutoSize = true;
            this.чиз.BackColor = System.Drawing.Color.Transparent;
            this.чиз.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.чиз.ForeColor = System.Drawing.Color.Cyan;
            this.чиз.Location = new System.Drawing.Point(133, 179);
            this.чиз.Name = "чиз";
            this.чиз.Size = new System.Drawing.Size(137, 29);
            this.чиз.TabIndex = 4;
            this.чиз.Text = "50 рублей";
            this.чиз.Click += new System.EventHandler(this.чиз_Click);
            // 
            // экл
            // 
            this.экл.AutoSize = true;
            this.экл.BackColor = System.Drawing.Color.Transparent;
            this.экл.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.экл.ForeColor = System.Drawing.Color.Cyan;
            this.экл.Location = new System.Drawing.Point(133, 297);
            this.экл.Name = "экл";
            this.экл.Size = new System.Drawing.Size(137, 29);
            this.экл.TabIndex = 5;
            this.экл.Text = "50 рублей";
            // 
            // Вернуться2
            // 
            this.Вернуться2.Location = new System.Drawing.Point(57, 386);
            this.Вернуться2.Name = "Вернуться2";
            this.Вернуться2.Size = new System.Drawing.Size(165, 24);
            this.Вернуться2.TabIndex = 6;
            this.Вернуться2.Text = "Вернуться";
            this.Вернуться2.UseVisualStyleBackColor = true;
            this.Вернуться2.Click += new System.EventHandler(this.Вернуться2_Click);
            // 
            // Эклер
            // 
            this.Эклер.Image = ((System.Drawing.Image)(resources.GetObject("Эклер.Image")));
            this.Эклер.Location = new System.Drawing.Point(21, 264);
            this.Эклер.Name = "Эклер";
            this.Эклер.Size = new System.Drawing.Size(99, 101);
            this.Эклер.TabIndex = 2;
            this.Эклер.TabStop = false;
            this.Эклер.MouseHover += new System.EventHandler(this.Эклер_MouseHover);
            // 
            // Десерты
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(282, 435);
            this.Controls.Add(this.Вернуться2);
            this.Controls.Add(this.экл);
            this.Controls.Add(this.чиз);
            this.Controls.Add(this.тир);
            this.Controls.Add(this.Эклер);
            this.Controls.Add(this.Чизкейк);
            this.Controls.Add(this.Тирамису);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Десерты";
            this.Text = "Десерты";
            ((System.ComponentModel.ISupportInitialize)(this.Тирамису)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Чизкейк)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Эклер)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Тирамису;
        private System.Windows.Forms.PictureBox Чизкейк;
        private System.Windows.Forms.Label тир;
        private System.Windows.Forms.Label чиз;
        private System.Windows.Forms.Label экл;
        private System.Windows.Forms.ToolTip Десерт_Помощь;
        private System.Windows.Forms.Button Вернуться2;
        private System.Windows.Forms.PictureBox Эклер;
    }
}
﻿
namespace Муржолье
{
    partial class Баланс
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Баланс));
            this.балаааанс = new System.Windows.Forms.Label();
            this.цена = new System.Windows.Forms.Label();
            this.заказ = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // балаааанс
            // 
            this.балаааанс.AutoSize = true;
            this.балаааанс.BackColor = System.Drawing.Color.Transparent;
            this.балаааанс.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.балаааанс.ForeColor = System.Drawing.Color.White;
            this.балаааанс.Location = new System.Drawing.Point(73, 34);
            this.балаааанс.Name = "балаааанс";
            this.балаааанс.Size = new System.Drawing.Size(129, 24);
            this.балаааанс.TabIndex = 0;
            this.балаааанс.Text = "Ваш баланс:";
            // 
            // цена
            // 
            this.цена.AutoSize = true;
            this.цена.BackColor = System.Drawing.Color.Transparent;
            this.цена.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.цена.ForeColor = System.Drawing.Color.White;
            this.цена.Location = new System.Drawing.Point(73, 69);
            this.цена.Name = "цена";
            this.цена.Size = new System.Drawing.Size(21, 24);
            this.цена.TabIndex = 1;
            this.цена.Text = "0";
            // 
            // заказ
            // 
            this.заказ.Location = new System.Drawing.Point(72, 105);
            this.заказ.Name = "заказ";
            this.заказ.Size = new System.Drawing.Size(130, 29);
            this.заказ.TabIndex = 2;
            this.заказ.Text = "Заказать";
            this.заказ.UseVisualStyleBackColor = true;
            this.заказ.Click += new System.EventHandler(this.button1_Click);
            // 
            // Баланс
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(284, 156);
            this.Controls.Add(this.заказ);
            this.Controls.Add(this.цена);
            this.Controls.Add(this.балаааанс);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Баланс";
            this.Text = "Баланс";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label балаааанс;
        private System.Windows.Forms.Label цена;
        private System.Windows.Forms.Button заказ;
    }
}
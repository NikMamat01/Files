﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Муржолье
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ControlBox = false;
            this.MinimizeBox = false;
            this.MaximizeBox = false;
        }

        private void выйти_Click(object sender, EventArgs e)
        {
            this.Hide();
            Муржолье f5 = new Муржолье();
            f5.Show();
        }

        private void открой_Click(object sender, EventArgs e)
        {
            const string file = @"D:\ПРОЕКТЫ ЗДЕСЬ\Муржолье\Админ\МУРЖОЛЬЕ_МЕНЮ";
            var application = new Microsoft.Office.Interop.Excel.Application();
            application.Visible = true;
            application.Workbooks.Open(file);
            открой.Enabled = false;
        }

        private void клик_Click(object sender, EventArgs e)
        {
            открой.Enabled = true;
        }

        private void закрыть_Click(object sender, EventArgs e)
        {
            
        }
    }
}

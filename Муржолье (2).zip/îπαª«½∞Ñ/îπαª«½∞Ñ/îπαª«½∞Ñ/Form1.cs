﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Муржолье
{
    public partial class Муржолье : Form
    {
        public Муржолье()
        {
            InitializeComponent();
        }

        private void Муржолье_Load(object sender, EventArgs e)
        {
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ControlBox = false;
            this.MinimizeBox = false;
            this.MaximizeBox = false;
            this.Текст.BackColor = System.Drawing.Color.Transparent;
        }

        private void Заказ_MouseHover(object sender, EventArgs e)
        {
            Подсказка.SetToolTip(Заказ, "Делайте ваш заказ!");
        }

        private void Прайслист_MouseHover(object sender, EventArgs e)
        {
            Подсказка.SetToolTip(Прайслист, "Здесь вы можете посмотреть цены.");
        }

        private void кафе_MouseHover(object sender, EventArgs e)
        {
            Подсказка.SetToolTip(Персонал, "Вход только для персонала кафе!");
        }

        private void Закрытие_MouseHover(object sender, EventArgs e)
        {
            Подсказка.SetToolTip(Закрытие, "Выйти из программы...");
        }

        private void Прайслист_Click(object sender, EventArgs e)
        {
            this.Hide();
            Прайслист f2 = new Прайслист();
            f2.Show();
        }

        private void Закрытие_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите выйти?", "Выход", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.No)
            {

            }
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void Заказ_Click(object sender, EventArgs e)
        {
            this.Hide();
            Заказ f22 = new Заказ();
            f22.Show();
        }

        private void кафе_Click(object sender, EventArgs e) // персонал
        {
            this.Hide();
            Персонал f222 = new Персонал();
            f222.Show();
        }

    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Муржолье
{
    public partial class Персонал : Form
    {
        public Персонал()
        {
            InitializeComponent();
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ControlBox = false;
            this.MinimizeBox = false;
            this.MaximizeBox = false;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8) // цифры и клавиша BackSpace
            {
                e.Handled = true;
            }
        }

        private void Войти_Click(object sender, EventArgs e)
        {
            if (Пароль.Text == "168")
            {
                this.Hide();
                Официант f1 = new Официант();
                f1.Show();
            }
            if (Пароль.Text == "754")
            {
                this.Hide();
                Admin f01 = new Admin();
                f01.Show();
            }
            else
            {
                MessageBox.Show("Неправильный пароль!");
                Пароль.Text = "";
            }
        }

        private void Персонал_Load(object sender, EventArgs e)
        {

        }
    }
}

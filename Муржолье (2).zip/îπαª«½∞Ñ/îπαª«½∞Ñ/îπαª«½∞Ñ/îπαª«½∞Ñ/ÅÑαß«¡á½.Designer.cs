﻿
namespace Муржолье
{
    partial class Персонал
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Персонал));
            this.Пароль = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Войти = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Пароль
            // 
            this.Пароль.Location = new System.Drawing.Point(91, 77);
            this.Пароль.Name = "Пароль";
            this.Пароль.Size = new System.Drawing.Size(100, 20);
            this.Пароль.TabIndex = 0;
            this.Пароль.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(56, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Введите пароль:";
            // 
            // Войти
            // 
            this.Войти.Location = new System.Drawing.Point(93, 110);
            this.Войти.Name = "Войти";
            this.Войти.Size = new System.Drawing.Size(97, 24);
            this.Войти.TabIndex = 2;
            this.Войти.Text = "Войти";
            this.Войти.UseVisualStyleBackColor = true;
            this.Войти.Click += new System.EventHandler(this.Войти_Click);
            // 
            // Персонал
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(287, 152);
            this.Controls.Add(this.Войти);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Пароль);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Персонал";
            this.Text = "Персонал";
            this.Load += new System.EventHandler(this.Персонал_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Пароль;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Войти;
    }
}
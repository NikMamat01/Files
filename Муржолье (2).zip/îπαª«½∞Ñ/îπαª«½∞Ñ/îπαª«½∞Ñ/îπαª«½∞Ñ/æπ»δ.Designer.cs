﻿
namespace Муржолье
{
    partial class Супы
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Супы));
            this.борщ = new System.Windows.Forms.PictureBox();
            this.щи = new System.Windows.Forms.PictureBox();
            this.уха = new System.Windows.Forms.PictureBox();
            this.бо = new System.Windows.Forms.Label();
            this.щщщщщ = new System.Windows.Forms.Label();
            this.ууууххххаааа = new System.Windows.Forms.Label();
            this.Супы_Помощь = new System.Windows.Forms.ToolTip(this.components);
            this.Вернуться3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.борщ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.щи)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.уха)).BeginInit();
            this.SuspendLayout();
            // 
            // борщ
            // 
            this.борщ.Image = ((System.Drawing.Image)(resources.GetObject("борщ.Image")));
            this.борщ.Location = new System.Drawing.Point(25, 36);
            this.борщ.Name = "борщ";
            this.борщ.Size = new System.Drawing.Size(100, 101);
            this.борщ.TabIndex = 0;
            this.борщ.TabStop = false;
            this.борщ.MouseHover += new System.EventHandler(this.борщ_MouseHover);
            // 
            // щи
            // 
            this.щи.Image = ((System.Drawing.Image)(resources.GetObject("щи.Image")));
            this.щи.Location = new System.Drawing.Point(25, 157);
            this.щи.Name = "щи";
            this.щи.Size = new System.Drawing.Size(100, 101);
            this.щи.TabIndex = 1;
            this.щи.TabStop = false;
            this.щи.MouseHover += new System.EventHandler(this.щи_MouseHover);
            // 
            // уха
            // 
            this.уха.Image = ((System.Drawing.Image)(resources.GetObject("уха.Image")));
            this.уха.Location = new System.Drawing.Point(25, 276);
            this.уха.Name = "уха";
            this.уха.Size = new System.Drawing.Size(100, 101);
            this.уха.TabIndex = 2;
            this.уха.TabStop = false;
            this.уха.MouseHover += new System.EventHandler(this.уха_MouseHover);
            // 
            // бо
            // 
            this.бо.AutoSize = true;
            this.бо.BackColor = System.Drawing.Color.Transparent;
            this.бо.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.бо.ForeColor = System.Drawing.Color.Cyan;
            this.бо.Location = new System.Drawing.Point(135, 69);
            this.бо.Name = "бо";
            this.бо.Size = new System.Drawing.Size(135, 25);
            this.бо.TabIndex = 3;
            this.бо.Text = "120 рублей";
            // 
            // щщщщщ
            // 
            this.щщщщщ.AutoSize = true;
            this.щщщщщ.BackColor = System.Drawing.Color.Transparent;
            this.щщщщщ.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.щщщщщ.ForeColor = System.Drawing.Color.Cyan;
            this.щщщщщ.Location = new System.Drawing.Point(135, 191);
            this.щщщщщ.Name = "щщщщщ";
            this.щщщщщ.Size = new System.Drawing.Size(135, 25);
            this.щщщщщ.TabIndex = 4;
            this.щщщщщ.Text = "120 рублей";
            // 
            // ууууххххаааа
            // 
            this.ууууххххаааа.AutoSize = true;
            this.ууууххххаааа.BackColor = System.Drawing.Color.Transparent;
            this.ууууххххаааа.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ууууххххаааа.ForeColor = System.Drawing.Color.Cyan;
            this.ууууххххаааа.Location = new System.Drawing.Point(135, 318);
            this.ууууххххаааа.Name = "ууууххххаааа";
            this.ууууххххаааа.Size = new System.Drawing.Size(135, 25);
            this.ууууххххаааа.TabIndex = 5;
            this.ууууххххаааа.Text = "120 рублей";
            // 
            // Вернуться3
            // 
            this.Вернуться3.Location = new System.Drawing.Point(66, 393);
            this.Вернуться3.Name = "Вернуться3";
            this.Вернуться3.Size = new System.Drawing.Size(148, 22);
            this.Вернуться3.TabIndex = 6;
            this.Вернуться3.Text = "Вернуться";
            this.Вернуться3.UseVisualStyleBackColor = true;
            this.Вернуться3.Click += new System.EventHandler(this.Вернуться3_Click);
            // 
            // Супы
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(282, 435);
            this.Controls.Add(this.Вернуться3);
            this.Controls.Add(this.ууууххххаааа);
            this.Controls.Add(this.щщщщщ);
            this.Controls.Add(this.бо);
            this.Controls.Add(this.уха);
            this.Controls.Add(this.щи);
            this.Controls.Add(this.борщ);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Супы";
            this.Text = "Супы";
            ((System.ComponentModel.ISupportInitialize)(this.борщ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.щи)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.уха)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox борщ;
        private System.Windows.Forms.PictureBox щи;
        private System.Windows.Forms.PictureBox уха;
        private System.Windows.Forms.Label бо;
        private System.Windows.Forms.Label щщщщщ;
        private System.Windows.Forms.Label ууууххххаааа;
        private System.Windows.Forms.ToolTip Супы_Помощь;
        private System.Windows.Forms.Button Вернуться3;
    }
}
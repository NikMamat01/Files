﻿
namespace Муржолье
{
    partial class Напитки
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Напитки));
            this.чай = new System.Windows.Forms.PictureBox();
            this.чаййй = new System.Windows.Forms.Label();
            this.ПомощьНапитки = new System.Windows.Forms.ToolTip(this.components);
            this.вода = new System.Windows.Forms.PictureBox();
            this.газировка = new System.Windows.Forms.PictureBox();
            this.водааа = new System.Windows.Forms.Label();
            this.газирооовка = new System.Windows.Forms.Label();
            this.Вернуться1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.чай)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.вода)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.газировка)).BeginInit();
            this.SuspendLayout();
            // 
            // чай
            // 
            this.чай.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("чай.BackgroundImage")));
            this.чай.Location = new System.Drawing.Point(24, 36);
            this.чай.Name = "чай";
            this.чай.Size = new System.Drawing.Size(101, 99);
            this.чай.TabIndex = 0;
            this.чай.TabStop = false;
            this.чай.Click += new System.EventHandler(this.чай_Click);
            this.чай.MouseHover += new System.EventHandler(this.чай_MouseHover);
            // 
            // чаййй
            // 
            this.чаййй.AutoSize = true;
            this.чаййй.BackColor = System.Drawing.Color.Transparent;
            this.чаййй.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.чаййй.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.чаййй.Location = new System.Drawing.Point(148, 67);
            this.чаййй.Name = "чаййй";
            this.чаййй.Size = new System.Drawing.Size(122, 25);
            this.чаййй.TabIndex = 1;
            this.чаййй.Text = "20 рублей";
            // 
            // вода
            // 
            this.вода.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("вода.BackgroundImage")));
            this.вода.Location = new System.Drawing.Point(24, 150);
            this.вода.Name = "вода";
            this.вода.Size = new System.Drawing.Size(101, 99);
            this.вода.TabIndex = 2;
            this.вода.TabStop = false;
            this.вода.MouseHover += new System.EventHandler(this.вода_MouseHover);
            // 
            // газировка
            // 
            this.газировка.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("газировка.BackgroundImage")));
            this.газировка.Image = ((System.Drawing.Image)(resources.GetObject("газировка.Image")));
            this.газировка.Location = new System.Drawing.Point(24, 269);
            this.газировка.Name = "газировка";
            this.газировка.Size = new System.Drawing.Size(101, 99);
            this.газировка.TabIndex = 3;
            this.газировка.TabStop = false;
            this.газировка.MouseHover += new System.EventHandler(this.газировка_MouseHover);
            // 
            // водааа
            // 
            this.водааа.AutoSize = true;
            this.водааа.BackColor = System.Drawing.Color.Transparent;
            this.водааа.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.водааа.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.водааа.Location = new System.Drawing.Point(148, 186);
            this.водааа.Name = "водааа";
            this.водааа.Size = new System.Drawing.Size(122, 25);
            this.водааа.TabIndex = 4;
            this.водааа.Text = "35 рублей";
            // 
            // газирооовка
            // 
            this.газирооовка.AutoSize = true;
            this.газирооовка.BackColor = System.Drawing.Color.Transparent;
            this.газирооовка.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.газирооовка.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.газирооовка.Location = new System.Drawing.Point(148, 299);
            this.газирооовка.Name = "газирооовка";
            this.газирооовка.Size = new System.Drawing.Size(122, 25);
            this.газирооовка.TabIndex = 5;
            this.газирооовка.Text = "40 рублей";
            // 
            // Вернуться1
            // 
            this.Вернуться1.Location = new System.Drawing.Point(58, 388);
            this.Вернуться1.Name = "Вернуться1";
            this.Вернуться1.Size = new System.Drawing.Size(172, 27);
            this.Вернуться1.TabIndex = 6;
            this.Вернуться1.Text = "Вернуться";
            this.Вернуться1.UseVisualStyleBackColor = true;
            this.Вернуться1.Click += new System.EventHandler(this.Вернуться1_Click);
            // 
            // Напитки
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(282, 435);
            this.Controls.Add(this.Вернуться1);
            this.Controls.Add(this.газирооовка);
            this.Controls.Add(this.водааа);
            this.Controls.Add(this.газировка);
            this.Controls.Add(this.вода);
            this.Controls.Add(this.чаййй);
            this.Controls.Add(this.чай);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Напитки";
            this.Text = "Напитки";
            ((System.ComponentModel.ISupportInitialize)(this.чай)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.вода)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.газировка)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox чай;
        private System.Windows.Forms.Label чаййй;
        private System.Windows.Forms.ToolTip ПомощьНапитки;
        private System.Windows.Forms.PictureBox вода;
        private System.Windows.Forms.PictureBox газировка;
        private System.Windows.Forms.Label водааа;
        private System.Windows.Forms.Label газирооовка;
        private System.Windows.Forms.Button Вернуться1;
    }
}
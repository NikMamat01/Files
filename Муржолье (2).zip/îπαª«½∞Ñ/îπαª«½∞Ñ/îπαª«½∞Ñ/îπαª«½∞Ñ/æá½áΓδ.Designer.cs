﻿
namespace Муржолье
{
    partial class Салаты
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Салаты));
            this.цезарь = new System.Windows.Forms.PictureBox();
            this.оливье = new System.Windows.Forms.PictureBox();
            this.селедка = new System.Windows.Forms.PictureBox();
            this.а25 = new System.Windows.Forms.Label();
            this.допу = new System.Windows.Forms.Label();
            this.ив = new System.Windows.Forms.Label();
            this.Салаты_Помощь = new System.Windows.Forms.ToolTip(this.components);
            this.Вернуться222 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.цезарь)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.оливье)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.селедка)).BeginInit();
            this.SuspendLayout();
            // 
            // цезарь
            // 
            this.цезарь.Image = ((System.Drawing.Image)(resources.GetObject("цезарь.Image")));
            this.цезарь.Location = new System.Drawing.Point(24, 33);
            this.цезарь.Name = "цезарь";
            this.цезарь.Size = new System.Drawing.Size(100, 100);
            this.цезарь.TabIndex = 0;
            this.цезарь.TabStop = false;
            this.цезарь.MouseHover += new System.EventHandler(this.цезарь_MouseHover);
            // 
            // оливье
            // 
            this.оливье.Image = ((System.Drawing.Image)(resources.GetObject("оливье.Image")));
            this.оливье.Location = new System.Drawing.Point(24, 158);
            this.оливье.Name = "оливье";
            this.оливье.Size = new System.Drawing.Size(100, 100);
            this.оливье.TabIndex = 1;
            this.оливье.TabStop = false;
            this.оливье.MouseHover += new System.EventHandler(this.оливье_MouseHover);
            // 
            // селедка
            // 
            this.селедка.Image = ((System.Drawing.Image)(resources.GetObject("селедка.Image")));
            this.селедка.Location = new System.Drawing.Point(24, 281);
            this.селедка.Name = "селедка";
            this.селедка.Size = new System.Drawing.Size(100, 100);
            this.селедка.TabIndex = 2;
            this.селедка.TabStop = false;
            this.селедка.MouseHover += new System.EventHandler(this.селедка_MouseHover);
            // 
            // а25
            // 
            this.а25.AutoSize = true;
            this.а25.BackColor = System.Drawing.Color.Transparent;
            this.а25.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.а25.ForeColor = System.Drawing.Color.Cyan;
            this.а25.Location = new System.Drawing.Point(135, 68);
            this.а25.Name = "а25";
            this.а25.Size = new System.Drawing.Size(135, 25);
            this.а25.TabIndex = 4;
            this.а25.Text = "130 рублей";
            // 
            // допу
            // 
            this.допу.AutoSize = true;
            this.допу.BackColor = System.Drawing.Color.Transparent;
            this.допу.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.допу.ForeColor = System.Drawing.Color.Cyan;
            this.допу.Location = new System.Drawing.Point(135, 199);
            this.допу.Name = "допу";
            this.допу.Size = new System.Drawing.Size(135, 25);
            this.допу.TabIndex = 5;
            this.допу.Text = "130 рублей";
            // 
            // ив
            // 
            this.ив.AutoSize = true;
            this.ив.BackColor = System.Drawing.Color.Transparent;
            this.ив.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ив.ForeColor = System.Drawing.Color.Cyan;
            this.ив.Location = new System.Drawing.Point(135, 319);
            this.ив.Name = "ив";
            this.ив.Size = new System.Drawing.Size(135, 25);
            this.ив.TabIndex = 6;
            this.ив.Text = "130 рублей";
            // 
            // Вернуться222
            // 
            this.Вернуться222.Location = new System.Drawing.Point(67, 397);
            this.Вернуться222.Name = "Вернуться222";
            this.Вернуться222.Size = new System.Drawing.Size(153, 26);
            this.Вернуться222.TabIndex = 7;
            this.Вернуться222.Text = "Вернуться";
            this.Вернуться222.UseVisualStyleBackColor = true;
            this.Вернуться222.Click += new System.EventHandler(this.Вернуться222_Click);
            // 
            // Салаты
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(282, 435);
            this.Controls.Add(this.Вернуться222);
            this.Controls.Add(this.ив);
            this.Controls.Add(this.допу);
            this.Controls.Add(this.а25);
            this.Controls.Add(this.селедка);
            this.Controls.Add(this.оливье);
            this.Controls.Add(this.цезарь);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Салаты";
            this.Text = "Салаты";
            ((System.ComponentModel.ISupportInitialize)(this.цезарь)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.оливье)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.селедка)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox цезарь;
        private System.Windows.Forms.PictureBox оливье;
        private System.Windows.Forms.PictureBox селедка;
        private System.Windows.Forms.Label а25;
        private System.Windows.Forms.Label допу;
        private System.Windows.Forms.Label ив;
        private System.Windows.Forms.ToolTip Салаты_Помощь;
        private System.Windows.Forms.Button Вернуться222;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Муржолье
{
    public partial class Официант : Form
    {
        public Официант()
        {
            InitializeComponent();
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ControlBox = false;
            this.MinimizeBox = false;
            this.MaximizeBox = false;
        }

        private void Официант_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) // вернуться
        {
            this.Hide();
            Муржолье f4 = new Муржолье();
            f4.Show();
        }

        private void nal_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"nal.txt");
            nal.Enabled = false;
        }

        private void karta_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"besnal.txt");
            karta.Enabled = false;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            karta.Enabled = true;
            nal.Enabled = true;
        }
    }
}

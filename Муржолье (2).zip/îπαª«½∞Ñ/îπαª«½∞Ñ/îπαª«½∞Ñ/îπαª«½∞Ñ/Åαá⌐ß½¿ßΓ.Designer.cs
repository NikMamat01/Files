﻿
namespace Муржолье
{
    partial class Прайслист
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Прайслист));
            this.Текст = new System.Windows.Forms.Label();
            this.Салаты = new System.Windows.Forms.Button();
            this.Горячее = new System.Windows.Forms.Button();
            this.Супы = new System.Windows.Forms.Button();
            this.Десерты = new System.Windows.Forms.Button();
            this.Напитки = new System.Windows.Forms.Button();
            this.Вернуться = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Текст
            // 
            this.Текст.AutoSize = true;
            this.Текст.Font = new System.Drawing.Font("Segoe Script", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Текст.ForeColor = System.Drawing.Color.White;
            this.Текст.Location = new System.Drawing.Point(28, 40);
            this.Текст.Name = "Текст";
            this.Текст.Size = new System.Drawing.Size(225, 48);
            this.Текст.TabIndex = 1;
            this.Текст.Text = "Прайс-лист\r\n";
            // 
            // Салаты
            // 
            this.Салаты.Location = new System.Drawing.Point(36, 105);
            this.Салаты.Name = "Салаты";
            this.Салаты.Size = new System.Drawing.Size(203, 33);
            this.Салаты.TabIndex = 2;
            this.Салаты.Text = "Салаты";
            this.Салаты.UseVisualStyleBackColor = true;
            this.Салаты.Click += new System.EventHandler(this.Салаты_Click);
            // 
            // Горячее
            // 
            this.Горячее.Location = new System.Drawing.Point(36, 144);
            this.Горячее.Name = "Горячее";
            this.Горячее.Size = new System.Drawing.Size(203, 33);
            this.Горячее.TabIndex = 3;
            this.Горячее.Text = "Горячее";
            this.Горячее.UseVisualStyleBackColor = true;
            this.Горячее.Click += new System.EventHandler(this.Горячее_Click);
            // 
            // Супы
            // 
            this.Супы.Location = new System.Drawing.Point(36, 183);
            this.Супы.Name = "Супы";
            this.Супы.Size = new System.Drawing.Size(203, 33);
            this.Супы.TabIndex = 4;
            this.Супы.Text = "Супы";
            this.Супы.UseVisualStyleBackColor = true;
            this.Супы.Click += new System.EventHandler(this.Супы_Click);
            // 
            // Десерты
            // 
            this.Десерты.Location = new System.Drawing.Point(36, 222);
            this.Десерты.Name = "Десерты";
            this.Десерты.Size = new System.Drawing.Size(203, 33);
            this.Десерты.TabIndex = 5;
            this.Десерты.Text = "Десерты";
            this.Десерты.UseVisualStyleBackColor = true;
            this.Десерты.Click += new System.EventHandler(this.Десерты_Click);
            // 
            // Напитки
            // 
            this.Напитки.Location = new System.Drawing.Point(36, 261);
            this.Напитки.Name = "Напитки";
            this.Напитки.Size = new System.Drawing.Size(203, 33);
            this.Напитки.TabIndex = 6;
            this.Напитки.Text = "Напитки";
            this.Напитки.UseVisualStyleBackColor = true;
            this.Напитки.Click += new System.EventHandler(this.Напитки_Click);
            // 
            // Вернуться
            // 
            this.Вернуться.Location = new System.Drawing.Point(36, 327);
            this.Вернуться.Name = "Вернуться";
            this.Вернуться.Size = new System.Drawing.Size(203, 33);
            this.Вернуться.TabIndex = 7;
            this.Вернуться.Text = "Вернуться";
            this.Вернуться.UseVisualStyleBackColor = true;
            this.Вернуться.Click += new System.EventHandler(this.Вернуться_Click);
            // 
            // Прайслист
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(282, 435);
            this.Controls.Add(this.Вернуться);
            this.Controls.Add(this.Напитки);
            this.Controls.Add(this.Десерты);
            this.Controls.Add(this.Супы);
            this.Controls.Add(this.Горячее);
            this.Controls.Add(this.Салаты);
            this.Controls.Add(this.Текст);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Прайслист";
            this.Text = "Муржолье \"Прайслист\"";
            this.Load += new System.EventHandler(this.Прайслист_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Текст;
        private System.Windows.Forms.Button Салаты;
        private System.Windows.Forms.Button Горячее;
        private System.Windows.Forms.Button Супы;
        private System.Windows.Forms.Button Десерты;
        private System.Windows.Forms.Button Напитки;
        private System.Windows.Forms.Button Вернуться;
    }
}
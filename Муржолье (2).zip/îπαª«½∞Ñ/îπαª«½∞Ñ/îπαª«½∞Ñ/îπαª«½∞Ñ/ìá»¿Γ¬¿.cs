﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Муржолье
{
    public partial class Напитки : Form
    {
        public Напитки()
        {
            InitializeComponent();
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ControlBox = false;
            this.MinimizeBox = false;
            this.MaximizeBox = false;
        }

        private void чай_MouseHover(object sender, EventArgs e)
        {
            ПомощьНапитки.SetToolTip(чай, "Чай черный / зелёный, 100 мл.");
        }

        private void чай_Click(object sender, EventArgs e)
        {
            //
        }

        private void вода_MouseHover(object sender, EventArgs e)
        {
            ПомощьНапитки.SetToolTip(вода, "Вода с газом / без газа, 500 мл.");
        }

        private void газировка_MouseHover(object sender, EventArgs e)
        {
            ПомощьНапитки.SetToolTip(газировка, "Pepsi / Mirinda / 7UP, 500 мл.");
        }

        private void Вернуться1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Прайслист f3 = new Прайслист();
            f3.Show();
        }
    }
}

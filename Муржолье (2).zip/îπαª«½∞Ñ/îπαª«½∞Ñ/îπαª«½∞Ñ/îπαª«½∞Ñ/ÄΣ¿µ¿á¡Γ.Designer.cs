﻿
namespace Муржолье
{
    partial class Официант
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Официант));
            this.Вернуться = new System.Windows.Forms.Button();
            this.karta = new System.Windows.Forms.Button();
            this.nal = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Вернуться
            // 
            this.Вернуться.Location = new System.Drawing.Point(162, 301);
            this.Вернуться.Name = "Вернуться";
            this.Вернуться.Size = new System.Drawing.Size(106, 53);
            this.Вернуться.TabIndex = 1;
            this.Вернуться.Text = "Выйти";
            this.Вернуться.UseVisualStyleBackColor = true;
            this.Вернуться.Click += new System.EventHandler(this.button1_Click);
            // 
            // karta
            // 
            this.karta.Location = new System.Drawing.Point(21, 37);
            this.karta.Name = "karta";
            this.karta.Size = new System.Drawing.Size(239, 23);
            this.karta.TabIndex = 2;
            this.karta.Text = "Заказ банковской картой";
            this.karta.UseVisualStyleBackColor = true;
            this.karta.Click += new System.EventHandler(this.karta_Click);
            // 
            // nal
            // 
            this.nal.Location = new System.Drawing.Point(21, 66);
            this.nal.Name = "nal";
            this.nal.Size = new System.Drawing.Size(239, 23);
            this.nal.TabIndex = 3;
            this.nal.Text = "Заказ наличными";
            this.nal.UseVisualStyleBackColor = true;
            this.nal.Click += new System.EventHandler(this.nal_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(21, 301);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 53);
            this.button1.TabIndex = 4;
            this.button1.Text = "Вернуть кликабельность";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Официант
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(287, 359);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.nal);
            this.Controls.Add(this.karta);
            this.Controls.Add(this.Вернуться);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Официант";
            this.Text = "Официант";
            this.Load += new System.EventHandler(this.Официант_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button Вернуться;
        private System.Windows.Forms.Button karta;
        private System.Windows.Forms.Button nal;
        private System.Windows.Forms.Button button1;
    }
}
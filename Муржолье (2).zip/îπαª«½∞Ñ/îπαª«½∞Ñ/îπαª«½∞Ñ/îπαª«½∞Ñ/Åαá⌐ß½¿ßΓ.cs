﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Муржолье
{
    public partial class Прайслист : Form
    {
        public Прайслист()
        {
            InitializeComponent();
        }

        private void Прайслист_Load(object sender, EventArgs e)
        {
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ControlBox = false;
            this.MinimizeBox = false;
            this.MaximizeBox = false;
            this.Текст.BackColor = System.Drawing.Color.Transparent;
        }

        private void Вернуться_Click(object sender, EventArgs e)
        {
            this.Hide();
            Муржолье f1 = new Муржолье();
            f1.Show();
        }

        private void Напитки_Click(object sender, EventArgs e)
        {
            this.Hide();
            Напитки f3 = new Напитки();
            f3.Show();
        }

        private void Десерты_Click(object sender, EventArgs e)
        {
            this.Hide();
            Десерты f4 = new Десерты();
            f4.Show();
        }

        private void Супы_Click(object sender, EventArgs e)
        {
            this.Hide();
            Супы f44 = new Супы();
            f44.Show();
        }

        private void Горячее_Click(object sender, EventArgs e)
        {
            this.Hide();
            Горячее f445 = new Горячее();
            f445.Show();
        }

        private void Салаты_Click(object sender, EventArgs e)
        {
            this.Hide();
            Салаты f4454 = new Салаты();
            f4454.Show();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Муржолье
{
    public partial class Супы : Form
    {
        public Супы()
        {
            InitializeComponent();
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ControlBox = false;
            this.MinimizeBox = false;
            this.MaximizeBox = false;
        }

        private void борщ_MouseHover(object sender, EventArgs e)
        {
            Супы_Помощь.SetToolTip(борщ, "Борщ со сметаной, 200 гр.");
        }

        private void Вернуться3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Прайслист f5 = new Прайслист();
            f5.Show();
        }

        private void щи_MouseHover(object sender, EventArgs e)
        {
            Супы_Помощь.SetToolTip(щи, "Зелёные щи со сметаной, 200 гр.");
        }

        private void уха_MouseHover(object sender, EventArgs e)
        {
            Супы_Помощь.SetToolTip(уха, "Уха из форели, 200 гр.");
        }
    }
}

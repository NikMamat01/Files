﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;




namespace Муржолье
{
    public partial class Заказ : Form
    {
        
        public Заказ()
        {
            InitializeComponent();
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ControlBox = false;
            this.MinimizeBox = false;
            this.MaximizeBox = false;
            Random rand = new Random();
            int value = rand.Next(500, 1000);
            баланс.Text = value.ToString();
        }

        private void закаааз_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Салаты"];
                double a = xlSht.Range["D3"].Value;
                double a1 = xlSht.Range["D4"].Value;
                double a2 = xlSht.Range["D5"].Value;
                xlSht = xlWB.Worksheets["Горячее"];
                double b = xlSht.Range["D3"].Value;
                double b1 = xlSht.Range["D4"].Value;
                double b2 = xlSht.Range["D5"].Value;
                xlSht = xlWB.Worksheets["Супы"];
                double c = xlSht.Range["D3"].Value;
                double c1 = xlSht.Range["D4"].Value;
                double c2 = xlSht.Range["D5"].Value;
                xlSht = xlWB.Worksheets["Десерты"];
                double d = xlSht.Range["D3"].Value;
                double d1 = xlSht.Range["D4"].Value;
                double d2 = xlSht.Range["D5"].Value;
                xlSht = xlWB.Worksheets["Напитки"];
                double e1 = xlSht.Range["D3"].Value;
                double e2 = xlSht.Range["D4"].Value;
                double e3 = xlSht.Range["D5"].Value;
                double e4 = xlSht.Range["D6"].Value;
                double e5 = xlSht.Range["D7"].Value;
                double e6 = xlSht.Range["D8"].Value;
                double e7 = xlSht.Range["D9"].Value;
                double k = 0;
                if (Цезарь.Enabled == false)
                {
                    k += a;
                }
                if (Оливье.Enabled == false)
                {
                    k += a1;
                }
                if (Селёдка.Enabled == false)
                {
                    k += a2;
                }
                if (Макароны.Enabled == false)
                {
                    k += b;
                }
                if (Картошка.Enabled == false)
                {
                    k += b1;
                }
                if (Плов.Enabled == false)
                {
                    k += b2;
                }
                if (Борщ.Enabled == false)
                {
                    k += c;
                }
                if (Щи.Enabled == false)
                {
                    k += c1;
                }
                if (Уха.Enabled == false)
                {
                    k += c2;
                }
                if (Тирамису.Enabled == false)
                {
                    k += d;
                }
                if (Чизкейк.Enabled == false)
                {
                    k += d1;
                }
                if (Эклер.Enabled == false)
                {
                    k += d2;
                }
                if (Чай.Enabled == false)
                {
                    k += e1;
                }
                if (зеленый.Enabled == false)
                {
                    k += e2;
                }
                if (Вода.Enabled == false)
                {
                    k += e3;
                }
                if (водасгазом.Enabled == false)
                {
                    k += e4;
                }
                if (Газировка.Enabled == false)
                {
                    k += e5;
                }
                if (миринда.Enabled == false)
                {
                    k += e6;
                }
                if (севенап.Enabled == false)
                {
                    k += e7;
                }
                double nal = Convert.ToDouble(баланс.Text);
                double sdacha1 = nal - k;
                итог.Text = k.ToString();
                sdacha.Text = sdacha1.ToString();
                картина.Visible = true;
                Чек.Items.Add("Итого:");
                Чек.Items.Add(итог.Text + " рублей");
                Чек.Items.Add("-----------------------");

                if (sdacha1 >= 0)
                {
                    вердикт.Text = "Оплата наличными или картой?";
                    кнопка.Enabled = true;
                    кнопка2.Enabled = true;
                }
                else
                {
                    вердикт.Text = "Оплата только банковской картой!";
                    кнопка.Enabled = false;
                    кнопка2.Enabled = true;
                }
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void checkguess()
        {

        }

        private void Цезарь_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Салаты"];
                string a = xlSht.Range["A3"].Value;
                double b = xlSht.Range["B3"].Value;
                double c = xlSht.Range["C3"].Value;
                double d = xlSht.Range["D3"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Цезарь.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Оливье_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Салаты"];
                string a = xlSht.Range["A4"].Value;
                double b = xlSht.Range["B4"].Value;
                double c = xlSht.Range["C4"].Value;
                double d = xlSht.Range["D4"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Оливье.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

            private void Селёдка_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Салаты"];
                string a = xlSht.Range["A5"].Value;
                double b = xlSht.Range["B5"].Value;
                double c = xlSht.Range["C5"].Value;
                double d = xlSht.Range["D5"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Селёдка.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

            private void Борщ_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Супы"];
                string a = xlSht.Range["A3"].Value;
                double b = xlSht.Range["B3"].Value;
                double c = xlSht.Range["C3"].Value;
                double d = xlSht.Range["D3"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Борщ.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

            private void Щи_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Супы"];
                string a = xlSht.Range["A4"].Value;
                double b = xlSht.Range["B4"].Value;
                double c = xlSht.Range["C4"].Value;
                double d = xlSht.Range["D4"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Щи.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Уха_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Супы"];
                string a = xlSht.Range["A5"].Value;
                double b = xlSht.Range["B5"].Value;
                double c = xlSht.Range["C5"].Value;
                double d = xlSht.Range["D5"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Уха.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Чай_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Напитки"];
                string a = xlSht.Range["A3"].Value;
                double b = xlSht.Range["B3"].Value;
                double c = xlSht.Range["C3"].Value;
                double d = xlSht.Range["D3"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " мл.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Чай.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

            private void Вода_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Напитки"];
                string a = xlSht.Range["A5"].Value;
                double b = xlSht.Range["B5"].Value;
                double c = xlSht.Range["C5"].Value;
                double d = xlSht.Range["D5"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " мл.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Вода.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Газировка_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Напитки"];
                string a = xlSht.Range["A7"].Value;
                double b = xlSht.Range["B7"].Value;
                double c = xlSht.Range["C7"].Value;
                double d = xlSht.Range["D7"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " мл.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Газировка.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Макароны_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Горячее"];
                string a = xlSht.Range["A3"].Value;
                double b = xlSht.Range["B3"].Value;
                double c = xlSht.Range["C3"].Value;
                double d = xlSht.Range["D3"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Макароны.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Картошка_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Горячее"];
                string a = xlSht.Range["A4"].Value;
                double b = xlSht.Range["B4"].Value;
                double c = xlSht.Range["C4"].Value;
                double d = xlSht.Range["D4"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Картошка.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Плов_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Горячее"];
                string a = xlSht.Range["A5"].Value;
                double b = xlSht.Range["B5"].Value;
                double c = xlSht.Range["C5"].Value;
                double d = xlSht.Range["D5"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Плов.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Тирамису_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Десерты"];
                string a = xlSht.Range["A3"].Value;
                double b = xlSht.Range["B3"].Value;
                double c = xlSht.Range["C3"].Value;
                double d = xlSht.Range["D3"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Тирамису.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Чизкейк_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Десерты"];
                string a = xlSht.Range["A4"].Value;
                double b = xlSht.Range["B4"].Value;
                double c = xlSht.Range["C4"].Value;
                double d = xlSht.Range["D4"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Чизкейк.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Эклер_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Десерты"];
                string a = xlSht.Range["A5"].Value;
                double b = xlSht.Range["B5"].Value;
                double c = xlSht.Range["C5"].Value;
                double d = xlSht.Range["D5"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " гр.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                Эклер.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void Чек_SelectedIndexChanged(object sender, EventArgs e)
        {
            

    }

        private void зеленый_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Напитки"];
                string a = xlSht.Range["A4"].Value;
                double b = xlSht.Range["B4"].Value;
                double c = xlSht.Range["C4"].Value;
                double d = xlSht.Range["D4"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " мл.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                зеленый.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void водасгазом_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath; 
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx"; 
            if ((System.IO.File.Exists(fileName)))   
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Напитки"];
                string a = xlSht.Range["A6"].Value;
                double b = xlSht.Range["B6"].Value;
                double c = xlSht.Range["C6"].Value;
                double d = xlSht.Range["D6"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " мл.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                водасгазом.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void миринда_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath;
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx";
            if ((System.IO.File.Exists(fileName)))
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Напитки"];
                string a = xlSht.Range["A8"].Value;
                double b = xlSht.Range["B8"].Value;
                double c = xlSht.Range["C8"].Value;
                double d = xlSht.Range["D8"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " мл.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                миринда.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void севенап_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath; 
            string fileName = path + @"\МУРЖОЛЬЕ_МЕНЮ.xlsx"; 
            if ((System.IO.File.Exists(fileName)))   
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWB;
                Excel.Worksheet xlSht;
                xlWB = xlApp.Workbooks.Open(fileName);
                xlSht = xlWB.Worksheets["Напитки"];
                string a = xlSht.Range["A9"].Value;
                double b = xlSht.Range["B9"].Value;
                double c = xlSht.Range["C9"].Value;
                double d = xlSht.Range["D9"].Value;
                Чек.Items.Add(a);
                Чек.Items.Add(b + " ккал.");
                Чек.Items.Add(c + " мл.");
                Чек.Items.Add(d + " руб.");
                Чек.Items.Add("-----------------------");
                севенап.Enabled = false;
                xlWB.Close(false);
            }
            else
            {
                MessageBox.Show("Файл с меню отсутствует");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void кнопка_Click(object sender, EventArgs e)
        {
            int bal = Int32.Parse(баланс.Text);
            int itog = Int32.Parse(итог.Text);
            int sdacha1 = Int32.Parse(sdacha.Text);
            Чек.Items.Add("Оплата наличными.");
            Чек.Items.Add("Наличные: " + bal + " рублей");
            Чек.Items.Add("Сдача: " + sdacha1 + " рублей");
            Чек.Items.Add("-----------------------");
            MessageBox.Show("Ваш заказ составил на сумму: " + (itog).ToString() + " рублей. Вы решили оплатить заказ наличными на сумму: " + (bal).ToString() + " рублей. Ваша сдача: " + (sdacha1).ToString() + " рублей. Ваш заказ принят! Приятного аппетита! :) ");
            const string sPath = "nal.txt";
            using (System.IO.StreamWriter sw = new System.IO.StreamWriter(sPath))
            {
                for (int i = 0; i < Чек.Items.Count; i++)
                    sw.WriteLine(Чек.Items[i].ToString());
            }
            this.Hide();
            Муржолье f22 = new Муржолье();
            f22.Show();
        }

        private void Заказ_Load(object sender, EventArgs e)
        {

        }

        private void кнопка2_Click(object sender, EventArgs e)
        {
            double itog = Convert.ToDouble(итог.Text);
            double keshbek = itog * 0.1;
            Чек.Items.Add("Оплата банковской картой.");
            Чек.Items.Add("Кэшбэк: " + keshbek + " рублей");
            Чек.Items.Add("-----------------------");
            MessageBox.Show("Ваш заказ составил на сумму: " + (itog).ToString() + " рублей. Вы решили оплатить заказ банковской картой. Мы дарим вам кэшбэк 10% от заказа, то есть: " + (keshbek).ToString() + " рублей. Ваш заказ принят! Приятного аппетита! :) ");
            const string sPath = "besnal.txt";
            using (System.IO.StreamWriter sw = new System.IO.StreamWriter(sPath))
            {
                for (int i = 0; i < Чек.Items.Count; i++)
                    sw.WriteLine(Чек.Items[i].ToString());
            }
            this.Hide();
            Муржолье f22 = new Муржолье();
            f22.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void итог_Click(object sender, EventArgs e)
        {

        }

        private void sdacha_Click(object sender, EventArgs e)
        {

        }

        private void баланс_Click(object sender, EventArgs e)
        {

        }
    }
}

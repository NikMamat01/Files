﻿
namespace Муржолье
{
    partial class Заказ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Заказ));
            this.Салаты = new System.Windows.Forms.GroupBox();
            this.Селёдка = new System.Windows.Forms.Button();
            this.Оливье = new System.Windows.Forms.Button();
            this.Цезарь = new System.Windows.Forms.Button();
            this.Супы = new System.Windows.Forms.GroupBox();
            this.Уха = new System.Windows.Forms.Button();
            this.Щи = new System.Windows.Forms.Button();
            this.Борщ = new System.Windows.Forms.Button();
            this.Горячее = new System.Windows.Forms.GroupBox();
            this.Плов = new System.Windows.Forms.Button();
            this.Картошка = new System.Windows.Forms.Button();
            this.Макароны = new System.Windows.Forms.Button();
            this.Десерты = new System.Windows.Forms.GroupBox();
            this.Эклер = new System.Windows.Forms.Button();
            this.Чизкейк = new System.Windows.Forms.Button();
            this.Тирамису = new System.Windows.Forms.Button();
            this.Напитки = new System.Windows.Forms.GroupBox();
            this.севенап = new System.Windows.Forms.Button();
            this.миринда = new System.Windows.Forms.Button();
            this.водасгазом = new System.Windows.Forms.Button();
            this.зеленый = new System.Windows.Forms.Button();
            this.Газировка = new System.Windows.Forms.Button();
            this.Вода = new System.Windows.Forms.Button();
            this.Чай = new System.Windows.Forms.Button();
            this.закаааз = new System.Windows.Forms.Button();
            this.Чек = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.баланс = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.итог = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.sdacha = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.картина = new System.Windows.Forms.PictureBox();
            this.вердикт = new System.Windows.Forms.Label();
            this.кнопка = new System.Windows.Forms.Button();
            this.кнопка2 = new System.Windows.Forms.Button();
            this.Салаты.SuspendLayout();
            this.Супы.SuspendLayout();
            this.Горячее.SuspendLayout();
            this.Десерты.SuspendLayout();
            this.Напитки.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.картина)).BeginInit();
            this.SuspendLayout();
            // 
            // Салаты
            // 
            this.Салаты.BackColor = System.Drawing.Color.Transparent;
            this.Салаты.Controls.Add(this.Селёдка);
            this.Салаты.Controls.Add(this.Оливье);
            this.Салаты.Controls.Add(this.Цезарь);
            this.Салаты.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Салаты.ForeColor = System.Drawing.Color.White;
            this.Салаты.Location = new System.Drawing.Point(23, 22);
            this.Салаты.Name = "Салаты";
            this.Салаты.Size = new System.Drawing.Size(130, 115);
            this.Салаты.TabIndex = 0;
            this.Салаты.TabStop = false;
            this.Салаты.Text = "Салаты";
            // 
            // Селёдка
            // 
            this.Селёдка.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Селёдка.ForeColor = System.Drawing.Color.Red;
            this.Селёдка.Location = new System.Drawing.Point(19, 85);
            this.Селёдка.Name = "Селёдка";
            this.Селёдка.Size = new System.Drawing.Size(91, 27);
            this.Селёдка.TabIndex = 2;
            this.Селёдка.Text = "Селёдка под шубой";
            this.Селёдка.UseVisualStyleBackColor = true;
            this.Селёдка.Click += new System.EventHandler(this.Селёдка_Click);
            // 
            // Оливье
            // 
            this.Оливье.ForeColor = System.Drawing.Color.Red;
            this.Оливье.Location = new System.Drawing.Point(19, 52);
            this.Оливье.Name = "Оливье";
            this.Оливье.Size = new System.Drawing.Size(91, 27);
            this.Оливье.TabIndex = 1;
            this.Оливье.Text = "Оливье";
            this.Оливье.UseVisualStyleBackColor = true;
            this.Оливье.Click += new System.EventHandler(this.Оливье_Click);
            // 
            // Цезарь
            // 
            this.Цезарь.ForeColor = System.Drawing.Color.Red;
            this.Цезарь.Location = new System.Drawing.Point(19, 19);
            this.Цезарь.Name = "Цезарь";
            this.Цезарь.Size = new System.Drawing.Size(91, 27);
            this.Цезарь.TabIndex = 0;
            this.Цезарь.Text = "Цезарь";
            this.Цезарь.UseVisualStyleBackColor = true;
            this.Цезарь.Click += new System.EventHandler(this.Цезарь_Click);
            // 
            // Супы
            // 
            this.Супы.BackColor = System.Drawing.Color.Transparent;
            this.Супы.Controls.Add(this.Уха);
            this.Супы.Controls.Add(this.Щи);
            this.Супы.Controls.Add(this.Борщ);
            this.Супы.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Супы.ForeColor = System.Drawing.Color.White;
            this.Супы.Location = new System.Drawing.Point(23, 151);
            this.Супы.Name = "Супы";
            this.Супы.Size = new System.Drawing.Size(130, 115);
            this.Супы.TabIndex = 1;
            this.Супы.TabStop = false;
            this.Супы.Text = "Супы";
            // 
            // Уха
            // 
            this.Уха.ForeColor = System.Drawing.Color.Red;
            this.Уха.Location = new System.Drawing.Point(19, 82);
            this.Уха.Name = "Уха";
            this.Уха.Size = new System.Drawing.Size(91, 27);
            this.Уха.TabIndex = 8;
            this.Уха.Text = "Уха";
            this.Уха.UseVisualStyleBackColor = true;
            this.Уха.Click += new System.EventHandler(this.Уха_Click);
            // 
            // Щи
            // 
            this.Щи.ForeColor = System.Drawing.Color.Red;
            this.Щи.Location = new System.Drawing.Point(19, 52);
            this.Щи.Name = "Щи";
            this.Щи.Size = new System.Drawing.Size(91, 27);
            this.Щи.TabIndex = 7;
            this.Щи.Text = "Щи";
            this.Щи.UseVisualStyleBackColor = true;
            this.Щи.Click += new System.EventHandler(this.Щи_Click);
            // 
            // Борщ
            // 
            this.Борщ.ForeColor = System.Drawing.Color.Red;
            this.Борщ.Location = new System.Drawing.Point(19, 19);
            this.Борщ.Name = "Борщ";
            this.Борщ.Size = new System.Drawing.Size(91, 27);
            this.Борщ.TabIndex = 6;
            this.Борщ.Text = "Борщ";
            this.Борщ.UseVisualStyleBackColor = true;
            this.Борщ.Click += new System.EventHandler(this.Борщ_Click);
            // 
            // Горячее
            // 
            this.Горячее.BackColor = System.Drawing.Color.Transparent;
            this.Горячее.Controls.Add(this.Плов);
            this.Горячее.Controls.Add(this.Картошка);
            this.Горячее.Controls.Add(this.Макароны);
            this.Горячее.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Горячее.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.Горячее.Location = new System.Drawing.Point(170, 22);
            this.Горячее.Name = "Горячее";
            this.Горячее.Size = new System.Drawing.Size(130, 115);
            this.Горячее.TabIndex = 1;
            this.Горячее.TabStop = false;
            this.Горячее.Text = "Горячее";
            // 
            // Плов
            // 
            this.Плов.ForeColor = System.Drawing.Color.Red;
            this.Плов.Location = new System.Drawing.Point(17, 82);
            this.Плов.Name = "Плов";
            this.Плов.Size = new System.Drawing.Size(91, 27);
            this.Плов.TabIndex = 5;
            this.Плов.Text = "Плов";
            this.Плов.UseVisualStyleBackColor = true;
            this.Плов.Click += new System.EventHandler(this.Плов_Click);
            // 
            // Картошка
            // 
            this.Картошка.ForeColor = System.Drawing.Color.Red;
            this.Картошка.Location = new System.Drawing.Point(17, 52);
            this.Картошка.Name = "Картошка";
            this.Картошка.Size = new System.Drawing.Size(91, 27);
            this.Картошка.TabIndex = 4;
            this.Картошка.Text = "Картошка";
            this.Картошка.UseVisualStyleBackColor = true;
            this.Картошка.Click += new System.EventHandler(this.Картошка_Click);
            // 
            // Макароны
            // 
            this.Макароны.ForeColor = System.Drawing.Color.Red;
            this.Макароны.Location = new System.Drawing.Point(17, 19);
            this.Макароны.Name = "Макароны";
            this.Макароны.Size = new System.Drawing.Size(91, 27);
            this.Макароны.TabIndex = 3;
            this.Макароны.Text = "Макароны";
            this.Макароны.UseVisualStyleBackColor = true;
            this.Макароны.Click += new System.EventHandler(this.Макароны_Click);
            // 
            // Десерты
            // 
            this.Десерты.BackColor = System.Drawing.Color.Transparent;
            this.Десерты.Controls.Add(this.Эклер);
            this.Десерты.Controls.Add(this.Чизкейк);
            this.Десерты.Controls.Add(this.Тирамису);
            this.Десерты.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Десерты.ForeColor = System.Drawing.Color.White;
            this.Десерты.Location = new System.Drawing.Point(170, 151);
            this.Десерты.Name = "Десерты";
            this.Десерты.Size = new System.Drawing.Size(130, 115);
            this.Десерты.TabIndex = 2;
            this.Десерты.TabStop = false;
            this.Десерты.Text = "Десерты";
            // 
            // Эклер
            // 
            this.Эклер.ForeColor = System.Drawing.Color.Red;
            this.Эклер.Location = new System.Drawing.Point(17, 82);
            this.Эклер.Name = "Эклер";
            this.Эклер.Size = new System.Drawing.Size(91, 27);
            this.Эклер.TabIndex = 11;
            this.Эклер.Text = "Эклер";
            this.Эклер.UseVisualStyleBackColor = true;
            this.Эклер.Click += new System.EventHandler(this.Эклер_Click);
            // 
            // Чизкейк
            // 
            this.Чизкейк.ForeColor = System.Drawing.Color.Red;
            this.Чизкейк.Location = new System.Drawing.Point(17, 52);
            this.Чизкейк.Name = "Чизкейк";
            this.Чизкейк.Size = new System.Drawing.Size(91, 27);
            this.Чизкейк.TabIndex = 10;
            this.Чизкейк.Text = "Чизкейк";
            this.Чизкейк.UseVisualStyleBackColor = true;
            this.Чизкейк.Click += new System.EventHandler(this.Чизкейк_Click);
            // 
            // Тирамису
            // 
            this.Тирамису.ForeColor = System.Drawing.Color.Red;
            this.Тирамису.Location = new System.Drawing.Point(17, 19);
            this.Тирамису.Name = "Тирамису";
            this.Тирамису.Size = new System.Drawing.Size(91, 27);
            this.Тирамису.TabIndex = 9;
            this.Тирамису.Text = "Тирамису";
            this.Тирамису.UseVisualStyleBackColor = true;
            this.Тирамису.Click += new System.EventHandler(this.Тирамису_Click);
            // 
            // Напитки
            // 
            this.Напитки.BackColor = System.Drawing.Color.Transparent;
            this.Напитки.Controls.Add(this.севенап);
            this.Напитки.Controls.Add(this.миринда);
            this.Напитки.Controls.Add(this.водасгазом);
            this.Напитки.Controls.Add(this.зеленый);
            this.Напитки.Controls.Add(this.Газировка);
            this.Напитки.Controls.Add(this.Вода);
            this.Напитки.Controls.Add(this.Чай);
            this.Напитки.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Напитки.ForeColor = System.Drawing.Color.White;
            this.Напитки.Location = new System.Drawing.Point(23, 282);
            this.Напитки.Name = "Напитки";
            this.Напитки.Size = new System.Drawing.Size(207, 140);
            this.Напитки.TabIndex = 3;
            this.Напитки.TabStop = false;
            this.Напитки.Text = "Напитки";
            // 
            // севенап
            // 
            this.севенап.ForeColor = System.Drawing.Color.Red;
            this.севенап.Location = new System.Drawing.Point(136, 95);
            this.севенап.Name = "севенап";
            this.севенап.Size = new System.Drawing.Size(59, 27);
            this.севенап.TabIndex = 18;
            this.севенап.Text = "7UP";
            this.севенап.UseVisualStyleBackColor = true;
            this.севенап.Click += new System.EventHandler(this.севенап_Click);
            // 
            // миринда
            // 
            this.миринда.ForeColor = System.Drawing.Color.Red;
            this.миринда.Location = new System.Drawing.Point(71, 95);
            this.миринда.Name = "миринда";
            this.миринда.Size = new System.Drawing.Size(59, 27);
            this.миринда.TabIndex = 17;
            this.миринда.Text = "Mirinda";
            this.миринда.UseVisualStyleBackColor = true;
            this.миринда.Click += new System.EventHandler(this.миринда_Click);
            // 
            // водасгазом
            // 
            this.водасгазом.ForeColor = System.Drawing.Color.Red;
            this.водасгазом.Location = new System.Drawing.Point(106, 49);
            this.водасгазом.Name = "водасгазом";
            this.водасгазом.Size = new System.Drawing.Size(94, 40);
            this.водасгазом.TabIndex = 16;
            this.водасгазом.Text = "Вода с газом";
            this.водасгазом.UseVisualStyleBackColor = true;
            this.водасгазом.Click += new System.EventHandler(this.водасгазом_Click);
            // 
            // зеленый
            // 
            this.зеленый.ForeColor = System.Drawing.Color.Red;
            this.зеленый.Location = new System.Drawing.Point(106, 19);
            this.зеленый.Name = "зеленый";
            this.зеленый.Size = new System.Drawing.Size(99, 27);
            this.зеленый.TabIndex = 15;
            this.зеленый.Text = "Чай зелёный";
            this.зеленый.UseVisualStyleBackColor = true;
            this.зеленый.Click += new System.EventHandler(this.зеленый_Click);
            // 
            // Газировка
            // 
            this.Газировка.ForeColor = System.Drawing.Color.Red;
            this.Газировка.Location = new System.Drawing.Point(6, 95);
            this.Газировка.Name = "Газировка";
            this.Газировка.Size = new System.Drawing.Size(59, 27);
            this.Газировка.TabIndex = 14;
            this.Газировка.Text = "Pepsi";
            this.Газировка.UseVisualStyleBackColor = true;
            this.Газировка.Click += new System.EventHandler(this.Газировка_Click);
            // 
            // Вода
            // 
            this.Вода.ForeColor = System.Drawing.Color.Red;
            this.Вода.Location = new System.Drawing.Point(6, 49);
            this.Вода.Name = "Вода";
            this.Вода.Size = new System.Drawing.Size(94, 40);
            this.Вода.TabIndex = 13;
            this.Вода.Text = "Вода без газа";
            this.Вода.UseVisualStyleBackColor = true;
            this.Вода.Click += new System.EventHandler(this.Вода_Click);
            // 
            // Чай
            // 
            this.Чай.ForeColor = System.Drawing.Color.Red;
            this.Чай.Location = new System.Drawing.Point(6, 19);
            this.Чай.Name = "Чай";
            this.Чай.Size = new System.Drawing.Size(94, 27);
            this.Чай.TabIndex = 12;
            this.Чай.Text = "Чай чёрный";
            this.Чай.UseVisualStyleBackColor = true;
            this.Чай.Click += new System.EventHandler(this.Чай_Click);
            // 
            // закаааз
            // 
            this.закаааз.Location = new System.Drawing.Point(249, 373);
            this.закаааз.Name = "закаааз";
            this.закаааз.Size = new System.Drawing.Size(100, 35);
            this.закаааз.TabIndex = 4;
            this.закаааз.Text = "Сделать заказ";
            this.закаааз.UseVisualStyleBackColor = true;
            this.закаааз.Click += new System.EventHandler(this.закаааз_Click);
            // 
            // Чек
            // 
            this.Чек.FormattingEnabled = true;
            this.Чек.Location = new System.Drawing.Point(357, 22);
            this.Чек.Name = "Чек";
            this.Чек.Size = new System.Drawing.Size(262, 342);
            this.Чек.TabIndex = 6;
            this.Чек.SelectedIndexChanged += new System.EventHandler(this.Чек_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(653, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 24);
            this.label1.TabIndex = 7;
            this.label1.Text = "Ваш баланс: ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // баланс
            // 
            this.баланс.AutoSize = true;
            this.баланс.BackColor = System.Drawing.Color.Transparent;
            this.баланс.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.баланс.ForeColor = System.Drawing.Color.White;
            this.баланс.Location = new System.Drawing.Point(653, 56);
            this.баланс.Name = "баланс";
            this.баланс.Size = new System.Drawing.Size(21, 24);
            this.баланс.TabIndex = 8;
            this.баланс.Text = "0";
            this.баланс.Click += new System.EventHandler(this.баланс_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(697, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 24);
            this.label2.TabIndex = 9;
            this.label2.Text = "рублей";
            // 
            // итог
            // 
            this.итог.AutoSize = true;
            this.итог.BackColor = System.Drawing.Color.Transparent;
            this.итог.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.итог.ForeColor = System.Drawing.Color.White;
            this.итог.Location = new System.Drawing.Point(644, 136);
            this.итог.Name = "итог";
            this.итог.Size = new System.Drawing.Size(21, 24);
            this.итог.TabIndex = 10;
            this.итог.Text = "0";
            this.итог.Click += new System.EventHandler(this.итог_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(653, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 24);
            this.label3.TabIndex = 11;
            this.label3.Text = "Итого:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(709, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 24);
            this.label4.TabIndex = 12;
            this.label4.Text = "рублей";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(653, 187);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 24);
            this.label5.TabIndex = 13;
            this.label5.Text = "Сдача:";
            // 
            // sdacha
            // 
            this.sdacha.AutoSize = true;
            this.sdacha.BackColor = System.Drawing.Color.Transparent;
            this.sdacha.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.sdacha.ForeColor = System.Drawing.Color.White;
            this.sdacha.Location = new System.Drawing.Point(644, 222);
            this.sdacha.Name = "sdacha";
            this.sdacha.Size = new System.Drawing.Size(21, 24);
            this.sdacha.TabIndex = 14;
            this.sdacha.Text = "0";
            this.sdacha.Click += new System.EventHandler(this.sdacha_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(709, 222);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 24);
            this.label6.TabIndex = 15;
            this.label6.Text = "рублей";
            // 
            // картина
            // 
            this.картина.Image = ((System.Drawing.Image)(resources.GetObject("картина.Image")));
            this.картина.Location = new System.Drawing.Point(6, 3);
            this.картина.Name = "картина";
            this.картина.Size = new System.Drawing.Size(345, 419);
            this.картина.TabIndex = 16;
            this.картина.TabStop = false;
            this.картина.Visible = false;
            // 
            // вердикт
            // 
            this.вердикт.AutoSize = true;
            this.вердикт.BackColor = System.Drawing.Color.Transparent;
            this.вердикт.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.вердикт.ForeColor = System.Drawing.Color.White;
            this.вердикт.Location = new System.Drawing.Point(644, 282);
            this.вердикт.Name = "вердикт";
            this.вердикт.Size = new System.Drawing.Size(43, 24);
            this.вердикт.TabIndex = 17;
            this.вердикт.Text = "???";
            // 
            // кнопка
            // 
            this.кнопка.Enabled = false;
            this.кнопка.Location = new System.Drawing.Point(657, 324);
            this.кнопка.Name = "кнопка";
            this.кнопка.Size = new System.Drawing.Size(163, 40);
            this.кнопка.TabIndex = 18;
            this.кнопка.Text = "Оплата наличными\r\n(0% кэшбэк)";
            this.кнопка.UseVisualStyleBackColor = true;
            this.кнопка.Click += new System.EventHandler(this.кнопка_Click);
            // 
            // кнопка2
            // 
            this.кнопка2.Enabled = false;
            this.кнопка2.Location = new System.Drawing.Point(657, 373);
            this.кнопка2.Name = "кнопка2";
            this.кнопка2.Size = new System.Drawing.Size(163, 40);
            this.кнопка2.TabIndex = 19;
            this.кнопка2.Text = "Оплата банковской картой\r\n(10% кэшбэк)";
            this.кнопка2.UseVisualStyleBackColor = true;
            this.кнопка2.Click += new System.EventHandler(this.кнопка2_Click);
            // 
            // Заказ
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1066, 432);
            this.Controls.Add(this.кнопка2);
            this.Controls.Add(this.кнопка);
            this.Controls.Add(this.вердикт);
            this.Controls.Add(this.картина);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.sdacha);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.итог);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.баланс);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Чек);
            this.Controls.Add(this.закаааз);
            this.Controls.Add(this.Напитки);
            this.Controls.Add(this.Десерты);
            this.Controls.Add(this.Горячее);
            this.Controls.Add(this.Супы);
            this.Controls.Add(this.Салаты);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Заказ";
            this.Text = "Заказ";
            this.Load += new System.EventHandler(this.Заказ_Load);
            this.Салаты.ResumeLayout(false);
            this.Супы.ResumeLayout(false);
            this.Горячее.ResumeLayout(false);
            this.Десерты.ResumeLayout(false);
            this.Напитки.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.картина)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox Салаты;
        private System.Windows.Forms.GroupBox Супы;
        private System.Windows.Forms.GroupBox Горячее;
        private System.Windows.Forms.GroupBox Десерты;
        private System.Windows.Forms.GroupBox Напитки;
        private System.Windows.Forms.Button закаааз;
        private System.Windows.Forms.ListBox Чек;
        private System.Windows.Forms.Button Цезарь;
        private System.Windows.Forms.Button Селёдка;
        private System.Windows.Forms.Button Оливье;
        private System.Windows.Forms.Button Уха;
        private System.Windows.Forms.Button Щи;
        private System.Windows.Forms.Button Борщ;
        private System.Windows.Forms.Button Плов;
        private System.Windows.Forms.Button Картошка;
        private System.Windows.Forms.Button Макароны;
        private System.Windows.Forms.Button Эклер;
        private System.Windows.Forms.Button Чизкейк;
        private System.Windows.Forms.Button Тирамису;
        private System.Windows.Forms.Button Газировка;
        private System.Windows.Forms.Button Вода;
        private System.Windows.Forms.Button Чай;
        private System.Windows.Forms.Button севенап;
        private System.Windows.Forms.Button миринда;
        private System.Windows.Forms.Button водасгазом;
        private System.Windows.Forms.Button зеленый;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label баланс;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label итог;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label sdacha;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox картина;
        private System.Windows.Forms.Label вердикт;
        private System.Windows.Forms.Button кнопка;
        private System.Windows.Forms.Button кнопка2;
    }
}
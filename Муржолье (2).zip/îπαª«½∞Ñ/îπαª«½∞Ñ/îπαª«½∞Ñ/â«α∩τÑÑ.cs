﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Муржолье
{
    public partial class Горячее : Form
    {
        public Горячее()
        {
            InitializeComponent();
        }

        private void Горячее_Load(object sender, EventArgs e)
        {
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ControlBox = false;
            this.MinimizeBox = false;
            this.MaximizeBox = false;
        }

        private void Вернуться30_Click(object sender, EventArgs e)
        {
            this.Hide();
            Прайслист f20 = new Прайслист();
            f20.Show();
        }

        private void pictureBox1_MouseHover(object sender, EventArgs e) // макароны
        {
            Горячее_Помощь.SetToolTip(макароны, "Макароны с сыром и охоничьими колбасками, 200 гр.");
        }

        private void картошка_MouseHover(object sender, EventArgs e)
        {
            Горячее_Помощь.SetToolTip(картошка, "Картошка с курицей, 200 гр.");
        }

        private void плов_MouseHover(object sender, EventArgs e)
        {
            Горячее_Помощь.SetToolTip(плов, "Плов с курицей, 200 гр.");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Муржолье
{
    public partial class Десерты : Form
    {
        public Десерты()
        {
            InitializeComponent();
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ControlBox = false;
            this.MinimizeBox = false;
            this.MaximizeBox = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            //
        }

        private void чиз_Click(object sender, EventArgs e)
        {
            //
        }

        private void Тирамису_MouseHover(object sender, EventArgs e)
        {
            Десерт_Помощь.SetToolTip(Тирамису, "Тирамису, 70 гр.");
        }

        private void Вернуться2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Прайслист f4 = new Прайслист();
            f4.Show();
        }

        private void Чизкейк_MouseHover(object sender, EventArgs e)
        {
            Десерт_Помощь.SetToolTip(Чизкейк, "Чизкейк, 70 гр.");
        }

        private void Эклер_MouseHover(object sender, EventArgs e)
        {
            Десерт_Помощь.SetToolTip(Эклер, "Эклер, 100 гр.");
        }
    }
}

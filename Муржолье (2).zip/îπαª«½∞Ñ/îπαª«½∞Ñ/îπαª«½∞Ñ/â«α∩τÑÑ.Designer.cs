﻿
namespace Муржолье
{
    partial class Горячее
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Горячее));
            this.макароны = new System.Windows.Forms.PictureBox();
            this.картошка = new System.Windows.Forms.PictureBox();
            this.плов = new System.Windows.Forms.PictureBox();
            this.а = new System.Windows.Forms.Label();
            this.а1 = new System.Windows.Forms.Label();
            this.а2 = new System.Windows.Forms.Label();
            this.Вернуться30 = new System.Windows.Forms.Button();
            this.Горячее_Помощь = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.макароны)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.картошка)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.плов)).BeginInit();
            this.SuspendLayout();
            // 
            // макароны
            // 
            this.макароны.Image = ((System.Drawing.Image)(resources.GetObject("макароны.Image")));
            this.макароны.Location = new System.Drawing.Point(20, 37);
            this.макароны.Name = "макароны";
            this.макароны.Size = new System.Drawing.Size(101, 100);
            this.макароны.TabIndex = 0;
            this.макароны.TabStop = false;
            this.макароны.MouseHover += new System.EventHandler(this.pictureBox1_MouseHover);
            // 
            // картошка
            // 
            this.картошка.Image = ((System.Drawing.Image)(resources.GetObject("картошка.Image")));
            this.картошка.Location = new System.Drawing.Point(20, 155);
            this.картошка.Name = "картошка";
            this.картошка.Size = new System.Drawing.Size(101, 100);
            this.картошка.TabIndex = 1;
            this.картошка.TabStop = false;
            this.картошка.MouseHover += new System.EventHandler(this.картошка_MouseHover);
            // 
            // плов
            // 
            this.плов.Image = ((System.Drawing.Image)(resources.GetObject("плов.Image")));
            this.плов.Location = new System.Drawing.Point(20, 274);
            this.плов.Name = "плов";
            this.плов.Size = new System.Drawing.Size(101, 100);
            this.плов.TabIndex = 2;
            this.плов.TabStop = false;
            this.плов.MouseHover += new System.EventHandler(this.плов_MouseHover);
            // 
            // а
            // 
            this.а.AutoSize = true;
            this.а.BackColor = System.Drawing.Color.Transparent;
            this.а.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.а.ForeColor = System.Drawing.Color.Cyan;
            this.а.Location = new System.Drawing.Point(135, 70);
            this.а.Name = "а";
            this.а.Size = new System.Drawing.Size(135, 25);
            this.а.TabIndex = 3;
            this.а.Text = "150 рублей";
            // 
            // а1
            // 
            this.а1.AutoSize = true;
            this.а1.BackColor = System.Drawing.Color.Transparent;
            this.а1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.а1.ForeColor = System.Drawing.Color.Cyan;
            this.а1.Location = new System.Drawing.Point(127, 192);
            this.а1.Name = "а1";
            this.а1.Size = new System.Drawing.Size(135, 25);
            this.а1.TabIndex = 4;
            this.а1.Text = "150 рублей";
            // 
            // а2
            // 
            this.а2.AutoSize = true;
            this.а2.BackColor = System.Drawing.Color.Transparent;
            this.а2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.а2.ForeColor = System.Drawing.Color.Cyan;
            this.а2.Location = new System.Drawing.Point(127, 313);
            this.а2.Name = "а2";
            this.а2.Size = new System.Drawing.Size(135, 25);
            this.а2.TabIndex = 5;
            this.а2.Text = "150 рублей";
            // 
            // Вернуться30
            // 
            this.Вернуться30.Location = new System.Drawing.Point(61, 390);
            this.Вернуться30.Name = "Вернуться30";
            this.Вернуться30.Size = new System.Drawing.Size(153, 24);
            this.Вернуться30.TabIndex = 6;
            this.Вернуться30.Text = "Вернуться";
            this.Вернуться30.UseVisualStyleBackColor = true;
            this.Вернуться30.Click += new System.EventHandler(this.Вернуться30_Click);
            // 
            // Горячее
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(282, 435);
            this.Controls.Add(this.Вернуться30);
            this.Controls.Add(this.а2);
            this.Controls.Add(this.а1);
            this.Controls.Add(this.а);
            this.Controls.Add(this.плов);
            this.Controls.Add(this.картошка);
            this.Controls.Add(this.макароны);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Горячее";
            this.Text = "Горячее";
            this.Load += new System.EventHandler(this.Горячее_Load);
            ((System.ComponentModel.ISupportInitialize)(this.макароны)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.картошка)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.плов)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox макароны;
        private System.Windows.Forms.PictureBox картошка;
        private System.Windows.Forms.PictureBox плов;
        private System.Windows.Forms.Label а;
        private System.Windows.Forms.Label а1;
        private System.Windows.Forms.Label а2;
        private System.Windows.Forms.Button Вернуться30;
        private System.Windows.Forms.ToolTip Горячее_Помощь;
    }
}
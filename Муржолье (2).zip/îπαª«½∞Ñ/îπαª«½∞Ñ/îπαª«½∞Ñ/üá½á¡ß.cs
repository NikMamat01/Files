﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Муржолье
{
    public partial class Баланс : Form
    {
        public Баланс()
        {
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ControlBox = false;
            this.MinimizeBox = false;
            this.MaximizeBox = false;
            InitializeComponent();
            Random rand = new Random();
            int value = rand.Next(500, 1000);
            цена.Text = value.ToString() + " рублей";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Заказ f22 = new Заказ();
            f22.Show();
        }
    }
}
